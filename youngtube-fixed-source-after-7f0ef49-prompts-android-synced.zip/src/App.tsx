import React, { useEffect, useState, useCallback, useRef, Suspense } from 'react';
import db, { Settings } from './db';
import { WORKER_URL } from './config';
import type { PlaylistPlaybackContext } from './services/playlists/playlistTypes';
import { checkAndRequestStoragePersistence, StoragePersistenceResult } from './storage';
import { PWAInstallButton } from './components/PWAInstallButton';
import { OfflineIndicator } from './components/OfflineIndicator';
import { useSessionTimer } from './hooks/useSessionTimer';
import { ensureChannelsArchiveSynced } from './filtering';
import { AppShell } from './shell/AppShell';
import { openCastPicker } from './services/castService';
import { startParentSession, endParentSession, endChildSession, createSessionId } from './services/telemetry';
import {
  fetchAnnouncements,
  getVisibleAnnouncements,
  markDismissed,
  type Announcement,
  type AnnouncementContext,
} from './services/announcements';

// Lazy-load heavy surfaces so kid-facing feed route starts immediately
const WelcomeValueScreen = React.lazy(() => import('./components/WelcomeValueScreen'));
const Onboarding = React.lazy(() => import('./components/Onboarding'));
const PostSetupChecklist = React.lazy(() => import('./components/PostSetupChecklist'));
const PinLockModal = React.lazy(() => import('./components/PinLockModal'));
const AdBlockNotice = React.lazy(() => import('./components/AdBlockNotice'));
const PlayerView = React.lazy(() => import('./screens/PlayerView').then((m) => ({ default: m.PlayerView })));
const SessionEndScreen = React.lazy(() => import('./components/SessionEndScreen'));
const AnnouncementModal = React.lazy(() => import('./components/AnnouncementModal'));
const DashboardShell = React.lazy(() => import('./components/dashboard/DashboardShell').then((m) => ({ default: m.DashboardShell })));
const ChannelsCountCard = React.lazy(() => import('./components/ChannelsCountCard'));
const ChildProfileSection = React.lazy(() => import('./components/ChildProfileSection').then((m) => ({ default: m.ChildProfileSection })));
const TimerSection = React.lazy(() => import('./components/dashboard/TimerSection').then((m) => ({ default: m.TimerSection })));
const TasteShiftCard = React.lazy(() => import('./components/TasteShiftCard').then((m) => ({ default: m.TasteShiftCard })));
const ChannelCurationByCategory = React.lazy(() => import('./components/ChannelCurationByCategory').then((m) => ({ default: m.ChannelCurationByCategory })));
const FilteringTab = React.lazy(() => import('./components/FilteringTab').then((m) => ({ default: m.FilteringTab })));
const SavedVideosTab = React.lazy(() => import('./components/SavedVideosTab').then((m) => ({ default: m.SavedVideosTab })));
const AddByUrlCard = React.lazy(() => import('./components/AddByUrlCard'));
const TimerTestCard = React.lazy(() => import('./components/TimerTestCard'));
import type { DashboardSectionId } from './components/dashboard/DashboardNav';

// Unified dashboard section loading skeleton
const SectionLoadingSkeleton: React.FC = () => (
  <div className="rounded-2xl border border-yt-border bg-yt-surface p-6 shadow-sm animate-pulse space-y-4">
    <div className="flex items-center gap-3">
      <div className="w-9 h-9 rounded-xl bg-yt-brand-soft" />
      <div className="space-y-1.5 flex-1">
        <div className="h-4 bg-yt-surface-muted rounded-full w-1/4" />
        <div className="h-3 bg-yt-surface-muted/60 rounded-full w-1/2" />
      </div>
    </div>
    <div className="h-28 bg-yt-surface-muted/40 rounded-xl border border-yt-border" />
  </div>
);
import {
  Database,
  Cloud,
  HardDrive,
  CheckCircle2,
  AlertTriangle,
  AlertCircle,
  RefreshCw,
  ShieldCheck,
  ShieldAlert,
  TableProperties,
  Layers,
  Lock,
  Unlock,
  SlidersHorizontal,
  KeyRound,
  Plus,
  Trash2,
  HelpCircle,
  Wifi,
  WifiOff,
  Clock,
  Sparkles,
  User,
  FolderKanban,
  Bookmark,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';

interface TestResult {
  loading: boolean;
  success?: boolean;
  message?: string;
  error?: string;
  timestamp?: string;
}

interface WorkerResult {
  loading: boolean;
  success?: boolean;
  isFromCache?: boolean;
  data?: Record<string, unknown>;
  error?: string;
  message?: string;
  timestamp?: string;
}

interface StorageState {
  loading: boolean;
  result?: StoragePersistenceResult;
}

export default function App() {
  const [dbResult, setDbResult] = useState<TestResult>({ loading: true });
  const [workerResult, setWorkerResult] = useState<WorkerResult>({ loading: true });
  const [storageResult, setStorageResult] = useState<StorageState>({ loading: true });

  // Onboarding & Settings State
  const [showWelcome, setShowWelcome] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [showPostSetupChecklist, setShowPostSetupChecklist] = useState(false);
  const [mainSettings, setMainSettings] = useState<Settings | null>(null);

  // Stage 5 Refresh trigger for channels count card
  const [channelsRefreshTrigger, setChannelsRefreshTrigger] = useState(0);
  const [savedVideosRefreshTrigger, setSavedVideosRefreshTrigger] = useState(0);
  const [channelsData, setChannelsData] = useState<any[] | null>(null);

  // Stable callback — prevents infinite re-fetch loop in ChannelsCountCard
  const handleChannelsLoaded = useCallback((data: any[]) => {
    setChannelsData(data);
  }, []);

  // Stable callback for admin backfill refresh
  const handleBackfillSuccess = useCallback(() => {
    setChannelsRefreshTrigger((prev) => prev + 1);
  }, []);

  // Hide a single video: drop it locally. Do NOT refetch the Worker archive.
  const handleVideoHidden = useCallback((videoId?: string) => {
    if (videoId) {
      setSuppressedVideoIds((prev) => (prev.includes(videoId) ? prev : [...prev, videoId]));
    }
  }, []);

  // Check if ?dev=1 is requested in URL
  const isDevModeParam = typeof window !== 'undefined' &&
    (new URLSearchParams(window.location.search).get('dev') === '1' || window.location.hash.includes('dev=1'));

  // Parent Dashboard & PIN Lock State
  const [showPinModal, setShowPinModal] = useState(false);
  const [isDashboardUnlocked, setIsDashboardUnlocked] = useState(false);
  // Default is 'kids' (real kid-facing interface)
  const [viewMode, setViewMode] = useState<'kids' | 'dashboard' | 'dev'>(isDevModeParam ? 'dev' : 'kids');
  const [showAdBlockModal, setShowAdBlockModal] = useState(false);
  const [showDemoPlayer, setShowDemoPlayer] = useState(false);
  const [activePlaybackVideo, setActivePlaybackVideo] = useState<{
    videoId: string;
    title?: string;
    channelName?: string;
    channelId?: string;
    localPath?: string;
    playlistContext?: PlaylistPlaybackContext;
  } | null>(null);
  const [devForceStop, setDevForceStop] = useState(false);
  const [suppressedVideoIds, setSuppressedVideoIds] = useState<string[]>([]);
  const [kidsAnnouncements, setKidsAnnouncements] = useState<Announcement[]>([]);
  const [parentAnnouncements, setParentAnnouncements] = useState<Announcement[]>([]);

  // Fetch announcements for Kid feed when viewMode is 'kids'
  useEffect(() => {
    if (showWelcome || showOnboarding || showPostSetupChecklist) return;
    if (viewMode !== 'kids') return;

    let cancelled = false;
    void (async () => {
      try {
        const items = await fetchAnnouncements();
        if (!cancelled) {
          const visible = getVisibleAnnouncements(items, 'kids');
          setKidsAnnouncements(visible);
        }
      } catch {
        // Fail-open: errors never block feed
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [viewMode, showWelcome, showOnboarding, showPostSetupChecklist]);

  // Fetch announcements for Parent dashboard when viewMode is 'dashboard'
  useEffect(() => {
    if (showWelcome || showOnboarding || showPostSetupChecklist) return;
    if (viewMode !== 'dashboard') return;

    let cancelled = false;
    void (async () => {
      try {
        const items = await fetchAnnouncements();
        if (!cancelled) {
          const visible = getVisibleAnnouncements(items, 'parent');
          setParentAnnouncements(visible);
        }
      } catch {
        // Fail-open: errors never block dashboard
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [viewMode, showWelcome, showOnboarding, showPostSetupChecklist]);

  const handleDismissKidsAnnouncement = useCallback((id: string) => {
    markDismissed(id, 'kids');
    setKidsAnnouncements((prev) => prev.filter((item) => item.id !== id));
  }, []);

  const handleDismissParentAnnouncement = useCallback((id: string) => {
    markDismissed(id, 'parent');
    setParentAnnouncements((prev) => prev.filter((item) => item.id !== id));
  }, []);

  // Player history uses browser entries only for actual Watch layers:
  // level 1 = Watch, level 2 = fullscreen, level 3 = settings sheet.
  // Miniplayer is playback state, not a history entry.
  const isPlayerFullscreenRef = useRef(false);
  const [isPlayerFullscreen, setIsPlayerFullscreen] = useState(false);
  const isPlayerMinimizedRef = useRef(false);
  const [isPlayerMinimized, setIsPlayerMinimized] = useState(false);
  const isPlayerSheetOpenRef = useRef(false);
  const [isPlayerSheetOpen, setIsPlayerSheetOpen] = useState(false);
  const playerHistoryLevelRef = useRef(0);
  const closingRef = useRef(false);

  const updatePlayerFullscreen = useCallback((val: boolean) => {
    setIsPlayerFullscreen(val);
    isPlayerFullscreenRef.current = val;
  }, []);

  const updatePlayerMinimized = useCallback((val: boolean) => {
    setIsPlayerMinimized(val);
    isPlayerMinimizedRef.current = val;
  }, []);

  const updatePlayerSheetOpen = useCallback((val: boolean) => {
    setIsPlayerSheetOpen(val);
    isPlayerSheetOpenRef.current = val;
  }, []);

  const pushPlayerHistory = useCallback((level: number, state: Record<string, unknown> = {}) => {
    if (typeof window === 'undefined') return;
    window.history.pushState(
      { ...state, ytPlayer: true, playerLevel: level },
      ''
    );
    playerHistoryLevelRef.current = level;
  }, []);

  const handleOpenDemoPlayer = useCallback(() => {
    updatePlayerMinimized(false);
    updatePlayerSheetOpen(false);
    updatePlayerFullscreen(false);
    if (typeof window !== 'undefined' && !window.history.state?.ytPlayer) {
      pushPlayerHistory(1, { fullscreen: false, sheetOpen: false });
    }
    setShowDemoPlayer(true);
  }, [pushPlayerHistory, updatePlayerFullscreen, updatePlayerMinimized, updatePlayerSheetOpen]);

  const handleSelectVideo = useCallback((
    videoId: string,
    title?: string,
    channelName?: string,
    channelId?: string,
    options?: { localPath?: string; fromDownloads?: boolean; playlistContext?: PlaylistPlaybackContext }
  ) => {
    updatePlayerMinimized(false);
    updatePlayerSheetOpen(false);
    updatePlayerFullscreen(false);
    if (typeof window !== 'undefined' && !window.history.state?.ytPlayer) {
      pushPlayerHistory(1, { fullscreen: false, sheetOpen: false });
    } else if (typeof window !== 'undefined' && window.history.state?.ytPlayer) {
      playerHistoryLevelRef.current = Number(window.history.state?.playerLevel || 1);
    }
    setActivePlaybackVideo({ videoId, title, channelName, channelId, localPath: options?.localPath, playlistContext: options?.playlistContext });
  }, [pushPlayerHistory, updatePlayerFullscreen, updatePlayerMinimized, updatePlayerSheetOpen]);

  const handlePlayerEnterFullscreen = useCallback(() => {
    if (typeof window !== 'undefined' && !window.history.state?.fullscreen) {
      pushPlayerHistory(2, { fullscreen: true, sheetOpen: false });
    }
    updatePlayerFullscreen(true);
  }, [pushPlayerHistory, updatePlayerFullscreen]);

  const handlePlayerExitFullscreen = useCallback(() => {
    if (typeof window !== 'undefined' && window.history.state?.ytPlayer && window.history.state?.fullscreen) {
      window.history.back();
      return;
    }
    updatePlayerFullscreen(false);
  }, [updatePlayerFullscreen]);

  const handlePlayerEnterMinimized = useCallback(() => {
    updatePlayerMinimized(true);
    updatePlayerSheetOpen(false);
    updatePlayerFullscreen(false);
    if (typeof window !== 'undefined' && window.history.state?.ytPlayer) {
      // Back consumes the Watch entry and lands on the underlying root/overlay,
      // while playback remains mounted in the miniplayer.
      window.history.back();
    }
  }, [updatePlayerFullscreen, updatePlayerMinimized, updatePlayerSheetOpen]);

  const handlePlayerExitMinimized = useCallback(() => {
    updatePlayerMinimized(false);
    if (typeof window !== 'undefined' && !window.history.state?.ytPlayer) {
      pushPlayerHistory(1, { fullscreen: false, sheetOpen: false });
    }
  }, [pushPlayerHistory, updatePlayerMinimized]);

  const handlePlayerOpenSheet = useCallback(() => {
    const nextLevel = 3;
    if (typeof window !== 'undefined' && !window.history.state?.sheetOpen) {
      pushPlayerHistory(nextLevel, { fullscreen: false, sheetOpen: true });
    }
    updatePlayerSheetOpen(true);
  }, [pushPlayerHistory, updatePlayerSheetOpen]);

  const handlePlayerCloseSheet = useCallback(() => {
    if (typeof window !== 'undefined' && window.history.state?.ytPlayer && window.history.state?.sheetOpen) {
      window.history.back();
      return;
    }
    updatePlayerSheetOpen(false);
  }, [updatePlayerSheetOpen]);

  const handleClosePlayer = useCallback(() => {
    closingRef.current = true;
    const level = playerHistoryLevelRef.current;

    updatePlayerMinimized(false);
    updatePlayerFullscreen(false);
    updatePlayerSheetOpen(false);
    setActivePlaybackVideo(null);
    setShowDemoPlayer(false);

    if (level > 0 && typeof window !== 'undefined') {
      window.history.go(-level);
    } else {
      playerHistoryLevelRef.current = 0;
      closingRef.current = false;
    }
  }, [updatePlayerFullscreen, updatePlayerMinimized, updatePlayerSheetOpen]);

  // Ensure the browser state is recoverable after direct state restoration.
  useEffect(() => {
    if ((activePlaybackVideo || showDemoPlayer) && typeof window !== 'undefined') {
      if (window.history.state?.ytPlayer) {
        playerHistoryLevelRef.current = Number(window.history.state?.playerLevel || 1);
      } else {
        pushPlayerHistory(1, { fullscreen: false, sheetOpen: false });
      }
    }
  }, [activePlaybackVideo, showDemoPlayer, pushPlayerHistory]);

  useEffect(() => {
    const handlePopState = (e: PopStateEvent) => {
      const targetLevel = Number(e.state?.playerLevel || 0);
      const currentLevel = playerHistoryLevelRef.current;

      if (closingRef.current) {
        playerHistoryLevelRef.current = targetLevel;
        if (targetLevel === 0) closingRef.current = false;
        return;
      }

      // Fullscreen Back: exit fullscreen, keep Watch at level 1.
      if (isPlayerFullscreenRef.current && targetLevel < currentLevel) {
        playerHistoryLevelRef.current = targetLevel;
        updatePlayerFullscreen(false);
        try {
          if (document.fullscreenElement || (document as any).webkitFullscreenElement) {
            if (typeof document.exitFullscreen === 'function') document.exitFullscreen().catch(() => {});
            else (document as any).webkitExitFullscreen?.();
          }
        } catch {}
        try { (screen.orientation as any)?.unlock?.(); } catch {}
        return;
      }

      // Settings sheet Back: close only the sheet.
      if (isPlayerSheetOpenRef.current && targetLevel < currentLevel) {
        playerHistoryLevelRef.current = targetLevel;
        updatePlayerSheetOpen(false);
        return;
      }

      // Returning from a navigation push opened on top of Watch: keep playback.
      if (e.state?.ytPlayer && targetLevel === currentLevel) {
        return;
      }

      // Re-expanded mini-player has a fresh level-1 Watch entry; no action needed.
      if (e.state?.ytPlayer && targetLevel > 0) {
        playerHistoryLevelRef.current = targetLevel;
        updatePlayerMinimized(false);
        return;
      }

      // Watch portrait Back: minimize, never stop playback. The browser has already
      // returned to the underlying root/overlay history entry.
      if (activePlaybackVideo || showDemoPlayer) {
        playerHistoryLevelRef.current = 0;
        updatePlayerMinimized(true);
        updatePlayerFullscreen(false);
        updatePlayerSheetOpen(false);
        return;
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [activePlaybackVideo, showDemoPlayer, updatePlayerFullscreen, updatePlayerMinimized, updatePlayerSheetOpen]);

  const [castNotice, setCastNotice] = useState<string | null>(null);

  const handleOpenCastPicker = useCallback(async () => {
    const result = await openCastPicker();
    if (!result.ok && result.message) {
      setCastNotice(result.message);
      window.setTimeout(() => setCastNotice(null), 4000);
    }
  }, []);

  // Track if YouTube player is actively playing (prevents billing paused/idle time)
  const [isPlayerPlaying, setIsPlayerPlaying] = useState(false);

  useEffect(() => {
    if (!activePlaybackVideo && !showDemoPlayer) {
      setIsPlayerPlaying(false);
    }
  }, [activePlaybackVideo, showDemoPlayer]);

  // Phase 8: Session Timer — count playback only (when kid view, player is open, AND actively playing)
  const isPlayerOpen = Boolean(activePlaybackVideo || showDemoPlayer);
  const isCountingSession = viewMode === 'kids' && isPlayerOpen && isPlayerPlaying;
  const sessionTimer = useSessionTimer(isCountingSession);

  // Parent Dashboard Navigation Section
  const [dashboardSection, setDashboardSection] = useState<DashboardSectionId>('child');

  // Tools nav visibility (persisted in localStorage or enabled via ?tools or ?dev=1 or 5 taps on title)
  const [showTools, setShowTools] = useState<boolean>(() => {
    try {
      const urlParams = new URLSearchParams(window.location.search);
      if (urlParams.has('tools') || urlParams.get('dev') === '1') return true;
      return localStorage.getItem('youngtube_show_tools') === 'true';
    } catch {
      return false;
    }
  });

  const handleToggleTools = useCallback(() => {
    setShowTools((prev) => {
      const next = !prev;
      try {
        localStorage.setItem('youngtube_show_tools', String(next));
      } catch (e) {
        console.warn('Failed to save showTools state', e);
      }
      if (!next && dashboardSection === 'tools') {
        setDashboardSection('child');
      }
      return next;
    });
  }, [dashboardSection]);

  useEffect(() => {
    if (!showTools && dashboardSection === 'tools') {
      setDashboardSection('child');
    }
  }, [showTools, dashboardSection]);

  // Check if main settings record exists
  const checkMainSettings = useCallback(async () => {
    try {
      const record = await db.settings.get('main');
      if (!record || !record.pinHash) {
        setShowWelcome(true);
        setShowOnboarding(false);
        setMainSettings(null);
      } else {
        // Ensure scheduleWindow and sessionLimitMinutes defaults if missing
        if (!record.scheduleWindow || typeof record.sessionLimitMinutes !== 'number') {
          const updatedRecord: Settings = {
            ...record,
            scheduleWindow: record.scheduleWindow || { start: '00:00', end: '23:59' },
            sessionLimitMinutes: record.sessionLimitMinutes ?? 60,
          };
          await db.settings.put(updatedRecord);
          setMainSettings(updatedRecord);
        } else {
          setMainSettings(record);
        }
        setShowWelcome(false);
        setShowOnboarding(false);
      }
    } catch {
      // Fallback
    }
  }, []);

  const runDatabaseTest = useCallback(async () => {
    setDbResult({ loading: true });
    const startTime = performance.now();
    try {
      // 1. Write test record
      const testId = '__test__';
      await db.settings.put({
        id: testId,
        blacklistWords: ['test_keyword'],
        sessionLimitMinutes: 45,
        preloadedListVersion: 1,
      });

      // 2. Read back and verify
      const retrieved = await db.settings.get(testId);
      if (!retrieved || retrieved.id !== testId) {
        throw new Error('فشل قراءة السجل التجريبي بعد كتابته مباشرة.');
      }

      // 3. Delete test record
      await db.settings.delete(testId);

      // 4. Verify deletion
      const afterDelete = await db.settings.get(testId);
      if (afterDelete) {
        throw new Error('فشل حذف السجل التجريبي من جدول الإعدادات.');
      }

      const durationMs = Math.round(performance.now() - startTime);

      setDbResult({
        loading: false,
        success: true,
        message: `تم التحقق بنجاح من قاعدة البيانات IndexedDB (Dexie v1). تم تنفيذ عمليات الكتابة، القراءة، والمسح بدقة خلال ${durationMs}ms.`,
        timestamp: new Date().toLocaleTimeString('ar-EG'),
      });
    } catch (err) {
      setDbResult({
        loading: false,
        success: false,
        error: err instanceof Error ? err.message : 'حدث خطأ غير معروف أثناء فحص قاعدة البيانات.',
        timestamp: new Date().toLocaleTimeString('ar-EG'),
      });
    }
  }, []);

  const runWorkerTest = useCallback(async () => {
    setWorkerResult({ loading: true });
    const isOnline = typeof navigator !== 'undefined' ? navigator.onLine : true;

    try {
      const res = await fetch(WORKER_URL);
      if (!res.ok) {
        throw new Error(`خطأ في استجابة الـ Worker: كود ${res.status}`);
      }
      const data = await res.json();

      // Check if response was retrieved while offline or from Service Worker cache
      const isFromCache = !isOnline;

      setWorkerResult({
        loading: false,
        success: true,
        isFromCache,
        data,
        message: isFromCache ? 'من الكاش (بدون اتصال حالي)' : 'متصل ويرد بنجاح',
        timestamp: new Date().toLocaleTimeString('ar-EG'),
      });
    } catch (err) {
      // Fallback check: attempt to read cached data or local fallback
      try {
        const fallbackRes = await fetch('/api/test-worker');
        const fallbackData = await fallbackRes.json();
        setWorkerResult({
          loading: false,
          success: true,
          isFromCache: !isOnline,
          data: fallbackData,
          message: !isOnline ? 'من الكاش (بدون اتصال حالي)' : 'متصل ويرد بنجاح (محلي)',
          timestamp: new Date().toLocaleTimeString('ar-EG'),
        });
      } catch {
        setWorkerResult({
          loading: false,
          success: false,
          error: err instanceof Error ? err.message : 'تعذر الاتصال بالـ Worker الخارجي.',
          timestamp: new Date().toLocaleTimeString('ar-EG'),
        });
      }
    }
  }, []);

  const runStoragePersistenceTest = useCallback(async () => {
    setStorageResult({ loading: true });
    const result = await checkAndRequestStoragePersistence();
    setStorageResult({
      loading: false,
      result,
    });
  }, []);

  useEffect(() => {
    checkMainSettings();
    // Persist storage on all modes (protects Dexie). Skip diagnostic Worker/DB tests in kids mode.
    void runStoragePersistenceTest();
  }, [checkMainSettings, runStoragePersistenceTest]);

  useEffect(() => {
    if (viewMode !== 'dev' && dashboardSection !== 'tools' && !isDevModeParam) return;
    runDatabaseTest();
    runWorkerTest();

    const handleConnectivityChange = () => {
      runWorkerTest();
    };
    window.addEventListener('online', handleConnectivityChange);
    window.addEventListener('offline', handleConnectivityChange);
    return () => {
      window.removeEventListener('online', handleConnectivityChange);
      window.removeEventListener('offline', handleConnectivityChange);
    };
  }, [viewMode, isDevModeParam, runDatabaseTest, runWorkerTest]);

  // Dashboard first-run: populate Dexie without mounting the giant archive cards into React state
  useEffect(() => {
    if (viewMode !== 'dashboard') return;
    let cancelled = false;
    let timer: number | undefined;
    const delays = [0, 15_000, 45_000];
    let attempt = 0;

    const run = async () => {
      const ok = await ensureChannelsArchiveSynced();
      if (cancelled || ok) return;
      attempt += 1;
      if (attempt < delays.length) {
        timer = window.setTimeout(() => {
          void run();
        }, delays[attempt]);
      }
    };

    timer = window.setTimeout(() => {
      void run();
    }, delays[0]);

    return () => {
      cancelled = true;
      if (timer !== undefined) window.clearTimeout(timer);
    };
  }, [viewMode]);

  // T1: Parent Dashboard Telemetry (fire-and-forget, privacy-preserving)
  const parentSessionRef = useRef<{ sessionId: string; startedAtMs: number } | null>(null);
  const endedParentSessionsRef = useRef<Set<string>>(new Set());

  const endCurrentParentSession = useCallback(() => {
    const current = parentSessionRef.current;
    if (!current) return;
    parentSessionRef.current = null;
    if (endedParentSessionsRef.current.has(current.sessionId)) return;
    endedParentSessionsRef.current.add(current.sessionId);
    endParentSession(current.sessionId, current.startedAtMs);
  }, []);

  useEffect(() => {
    if (viewMode === 'dashboard') {
      if (!parentSessionRef.current) {
        const sessionId = startParentSession();
        parentSessionRef.current = { sessionId, startedAtMs: Date.now() };
      }
    } else {
      endCurrentParentSession();
    }
  }, [viewMode, endCurrentParentSession]);

  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        if (viewMode === 'dashboard') {
          endCurrentParentSession();
        }
      } else {
        if (viewMode === 'dashboard' && !parentSessionRef.current) {
          const sessionId = startParentSession();
          parentSessionRef.current = { sessionId, startedAtMs: Date.now() };
        }
      }
    };

    const handlePageHide = () => {
      if (viewMode === 'dashboard') {
        endCurrentParentSession();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('pagehide', handlePageHide);
    window.addEventListener('beforeunload', handlePageHide);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('pagehide', handlePageHide);
      window.removeEventListener('beforeunload', handlePageHide);
      endCurrentParentSession();
    };
  }, [viewMode, endCurrentParentSession]);

  // Open Dashboard handler
  const handleOpenDashboard = () => {
    if (isDashboardUnlocked) {
      setViewMode('dashboard');
    } else {
      setShowPinModal(true);
    }
  };

  const handleUnlockSuccess = () => {
    setIsDashboardUnlocked(true);
    setShowPinModal(false);
    setViewMode('dashboard');
    checkMainSettings();
  };

  const handleLockDashboard = () => {
    setIsDashboardUnlocked(false);
    setViewMode('kids');
  };

  // Finish first-run setup & navigate to KidHomeScreen
  const handleFinishFirstSetup = async () => {
    try {
      await db.settings.update('main', { hasCompletedFirstSetup: true });
      if (mainSettings) {
        setMainSettings({ ...mainSettings, hasCompletedFirstSetup: true });
      }
      setIsDashboardUnlocked(false);
      setViewMode('kids');
    } catch (err) {
      console.error('Failed to finish first setup:', err);
      setIsDashboardUnlocked(false);
      setViewMode('kids');
    }
  };

  // Reset Onboarding (for testing purposes)
  const handleResetForOnboardingTest = async () => {
    if (window.confirm('هل تريد إعادة تعيين إعدادات main واختبار شاشة Onboarding مجدداً؟')) {
      await db.settings.delete('main');
      setIsDashboardUnlocked(false);
      setViewMode('kids');
      checkMainSettings();
    }
  };

  // Phase 8: Session forceStop condition (limit reached OR outside schedule window OR dev force stop)
  const forceStop = sessionTimer.isLimitReached || !sessionTimer.isWithinScheduleWindow || devForceStop;

  // Session safety: if forceStop is true while player (or mini-player) is open, ensure it fully closes via handleClosePlayer
  useEffect(() => {
    if (forceStop && (activePlaybackVideo || showDemoPlayer)) {
      handleClosePlayer();
    }
  }, [forceStop, activePlaybackVideo, showDemoPlayer, handleClosePlayer]);

  // T2: Child Watch Telemetry (summed PLAYING seconds only, fire-and-forget)
  const childSessionRef = useRef<{
    sessionId: string;
    accumulatedSec: number;
    segmentStartedAtMs: number | null;
  } | null>(null);
  const endedChildSessionsRef = useRef<Set<string>>(new Set());

  const flushChildSession = useCallback(() => {
    const current = childSessionRef.current;
    if (!current) return;
    childSessionRef.current = null;

    let finalSec = current.accumulatedSec;
    if (current.segmentStartedAtMs !== null) {
      finalSec += (Date.now() - current.segmentStartedAtMs) / 1000;
    }

    if (!endedChildSessionsRef.current.has(current.sessionId)) {
      endedChildSessionsRef.current.add(current.sessionId);
      endChildSession(current.sessionId, finalSec);
    }
  }, []);

  useEffect(() => {
    const shouldEnd = !isPlayerOpen || viewMode !== 'kids' || forceStop;

    if (shouldEnd) {
      flushChildSession();
      return;
    }

    // Player open in kids mode without forceStop
    if (isPlayerPlaying) {
      if (!childSessionRef.current) {
        // A) Start session (lazy on actual playback)
        const sessionId = createSessionId();
        childSessionRef.current = {
          sessionId,
          accumulatedSec: 0,
          segmentStartedAtMs: Date.now(),
        };
      } else if (childSessionRef.current.segmentStartedAtMs === null) {
        // C) Resume playing
        childSessionRef.current.segmentStartedAtMs = Date.now();
      }
    } else {
      // B) Pause / stop playing (player still open)
      if (childSessionRef.current && childSessionRef.current.segmentStartedAtMs !== null) {
        childSessionRef.current.accumulatedSec +=
          (Date.now() - childSessionRef.current.segmentStartedAtMs) / 1000;
        childSessionRef.current.segmentStartedAtMs = null;
      }
    }
  }, [isPlayerOpen, isPlayerPlaying, viewMode, forceStop, flushChildSession]);

  useEffect(() => {
    const handlePageHide = () => {
      flushChildSession();
    };

    window.addEventListener('pagehide', handlePageHide);
    window.addEventListener('beforeunload', handlePageHide);

    return () => {
      window.removeEventListener('pagehide', handlePageHide);
      window.removeEventListener('beforeunload', handlePageHide);
      flushChildSession();
    };
  }, [flushChildSession]);

  return (
    <div className="min-h-screen font-sans">
      {/* 1) Welcome Value Screen */}
      {showWelcome && (
        <Suspense fallback={null}>
          <WelcomeValueScreen
            onStartSetup={() => {
              setShowWelcome(false);
              setShowOnboarding(true);
            }}
          />
        </Suspense>
      )}

      {/* 2) Onboarding Modal */}
      {!showWelcome && showOnboarding && (
        <Suspense fallback={null}>
          <Onboarding
            onComplete={async () => {
              setShowOnboarding(false);
              await checkMainSettings();
              setShowPostSetupChecklist(true);
            }}
          />
        </Suspense>
      )}

      {/* 3) Post-Setup Checklist Modal */}
      {!showWelcome && !showOnboarding && showPostSetupChecklist && (
        <Suspense fallback={null}>
          <PostSetupChecklist
            onFinish={() => {
              setShowPostSetupChecklist(false);
              try {
                localStorage.setItem('yt_post_setup_checklist_done_v1', '1');
              } catch {
                // Ignore storage errors
              }
              setViewMode('kids');
            }}
            onGoDashboard={() => {
              setShowPostSetupChecklist(false);
              try {
                localStorage.setItem('yt_post_setup_checklist_done_v1', '1');
              } catch {
                // Ignore storage errors
              }
              setIsDashboardUnlocked(true);
              setViewMode('dashboard');
            }}
          />
        </Suspense>
      )}

      {/* Announcements Modal - Kids Track */}
      {!showWelcome && !showOnboarding && !showPostSetupChecklist && viewMode === 'kids' && kidsAnnouncements.length > 0 && (
        <Suspense fallback={null}>
          <AnnouncementModal
            items={kidsAnnouncements}
            onDismiss={handleDismissKidsAnnouncement}
            contextLabel="رسالة للأطفال والعائلة"
          />
        </Suspense>
      )}

      {/* Announcements Modal - Parent Track */}
      {!showWelcome && !showOnboarding && !showPostSetupChecklist && viewMode === 'dashboard' && parentAnnouncements.length > 0 && (
        <Suspense fallback={null}>
          <AnnouncementModal
            items={parentAnnouncements}
            onDismiss={handleDismissParentAnnouncement}
            contextLabel="تنبيه للوالدين"
          />
        </Suspense>
      )}

      {/* PIN Lock Modal */}
      <Suspense fallback={null}>
        <PinLockModal
          isOpen={showPinModal}
          onClose={() => setShowPinModal(false)}
          onUnlockSuccess={handleUnlockSuccess}
        />
      </Suspense>

      {/* Phase 9: AdBlock Notice Modal */}
      {showAdBlockModal && (
        <Suspense fallback={null}>
          <AdBlockNotice
            mode="modal"
            onClose={() => setShowAdBlockModal(false)}
          />
        </Suspense>
      )}

      {/* Real Video Player Overlay */}
      {(activePlaybackVideo || showDemoPlayer) && (
        <Suspense
          fallback={
            <div className="fixed inset-0 z-50 bg-black flex items-center justify-center">
              <div className="w-10 h-10 border-4 border-yt-brand/20 border-t-yt-brand rounded-full animate-spin" />
            </div>
          }
        >
          <PlayerView
            videoId={activePlaybackVideo?.videoId || 's6X_Q54_PBs'}
            videoTitle={activePlaybackVideo?.title || 'Alphablocks - مغامرة الحروف الإنجليزية والكلمات السحرية للأطفال'}
            channelTitle={activePlaybackVideo?.channelName || 'Alphablocks'}
            channelId={activePlaybackVideo?.channelId}
            onOpenChannel={(channelId) => {
              // Channel push is owned by AppShell's navigation layer.
              window.dispatchEvent(new CustomEvent('youngtube-open-channel', { detail: channelId }));
            }}
            onOpenSearch={() => {
              window.dispatchEvent(new Event('youngtube-open-search'));
            }}
            localPath={activePlaybackVideo?.localPath}
            playlistContext={activePlaybackVideo?.playlistContext}
            onVideoHidden={handleVideoHidden}
            onChannelBlocked={handleBackfillSuccess}
            onClose={handleClosePlayer}
            onEnded={() => {
              console.log('Video finished playing cleanly');
            }}
            forceStop={forceStop}
            isFullscreen={isPlayerFullscreen}
            onEnterFullscreen={handlePlayerEnterFullscreen}
            onExitFullscreen={handlePlayerExitFullscreen}
            isMinimized={isPlayerMinimized}
            onEnterMinimized={handlePlayerEnterMinimized}
            onExitMinimized={handlePlayerExitMinimized}
            isSheetOpen={isPlayerSheetOpen}
            onOpenSheet={handlePlayerOpenSheet}
            onCloseSheet={handlePlayerCloseSheet}
            onPlayingChange={setIsPlayerPlaying}
          />
        </Suspense>
      )}

      {/* Background archive sync lives in ensureChannelsArchiveSynced (kids + dashboard).
          Do not mount hidden archive summary widgets here — they put the full Worker payload into React state
          and can double-fetch in some modes. */}

      {/* Phase 8: Full-Screen Session Takeover when session limit reached */}
      {sessionTimer.isLimitReached && viewMode !== 'dashboard' ? (
        <Suspense fallback={null}>
          <SessionEndScreen
            isLimitReached={sessionTimer.isLimitReached}
            isWithinScheduleWindow={sessionTimer.isWithinScheduleWindow}
            onParentUnlock={handleOpenDashboard}
            onResetForTesting={sessionTimer.resetTodayUsage}
          />
        </Suspense>
      ) : viewMode === 'kids' ? (
        <>
        <AppShell
          onOpenDemoPlayer={handleOpenDemoPlayer}
          onSelectVideo={handleSelectVideo}
          onOpenParentDashboard={handleOpenDashboard}
          onCast={handleOpenCastPicker}
          refreshTrigger={channelsRefreshTrigger}
          suppressedVideoIds={suppressedVideoIds}
          isPlayerOpen={isPlayerOpen}
          isPlayerMinimized={isPlayerMinimized}
          isDevModeParam={isDevModeParam}
          devForceStop={devForceStop}
          onToggleDevForceStop={() => setDevForceStop((prev) => !prev)}
        />
        {castNotice && (
          <div className="fixed top-[calc(env(safe-area-inset-top)+4.5rem)] left-1/2 -translate-x-1/2 z-[80] max-w-[calc(100vw-2rem)] rounded-2xl border border-yt-border bg-yt-surface px-4 py-3 text-xs font-semibold text-yt-text shadow-xl">
            {castNotice}
          </div>
        )}
        </>
      ) : (
        <Suspense
          fallback={
            <div className="min-h-screen bg-yt-bg flex flex-col items-center justify-center p-6 text-center space-y-4">
              <div className="w-10 h-10 border-4 border-yt-brand/20 border-t-yt-brand rounded-full animate-spin" />
              <p className="text-xs font-semibold text-yt-text-muted">جاري فتح لوحة الوالدين...</p>
            </div>
          }
        >
          <DashboardShell
            activeSection={dashboardSection}
            onSelectSection={setDashboardSection}
            onClose={handleLockDashboard}
            onLock={handleLockDashboard}
            hasIncompleteSetup={!mainSettings?.hasCompletedFirstSetup}
            showTools={showTools}
            onToggleTools={handleToggleTools}
            headerSlot={<PWAInstallButton />}
          >
          {/* First-Run Welcome / Guidance Banner */}
            {!mainSettings?.hasCompletedFirstSetup && (
              <div
                id="first-run-setup-banner"
                className="p-5 sm:p-6 rounded-3xl bg-gradient-to-l from-yt-brand to-orange-500 text-white shadow-md flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
              >
                <div className="flex items-start sm:items-center gap-3.5">
                  <div className="w-11 h-11 rounded-2xl bg-white/20 flex items-center justify-center shrink-0">
                    <Sparkles className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-base sm:text-lg font-bold">
                      قبل ما تبدأ، راجع القنوات والاهتمامات دي
                    </h2>
                    <p className="text-xs text-white/90 mt-0.5 max-w-xl leading-relaxed">
                      ألقِ نظرة سريعة على ملف الطفل، واهتماماته المفضلة، والقنوات وتصنيفاتها لضمان تجربة آمنة وممتعة 100%. عند الانتهاء اضغط زر البدء بالأسفل.
                    </p>
                  </div>
                </div>

                <button
                  id="first-run-top-start-btn"
                  type="button"
                  onClick={handleFinishFirstSetup}
                  className="px-5 py-2.5 rounded-2xl bg-white hover:bg-yt-brand-soft text-yt-text text-xs sm:text-sm font-bold shadow-sm transition shrink-0 flex items-center gap-2 cursor-pointer"
                >
                  <span>ابدأ استخدام الطفل</span>
                  <span>→</span>
                </button>
              </div>
            )}

          {/* SECTION: ملف الطفل */}
          {dashboardSection === 'child' && (
            <div id="section-child" className="space-y-6">
              <Suspense fallback={<SectionLoadingSkeleton />}>
                <ChildProfileSection onSaved={checkMainSettings} />
              </Suspense>
            </div>
          )}

          {/* SECTION: مواعيد التشغيل */}
          {dashboardSection === 'timer' && (
            <div id="section-timer" className="space-y-6">
              <Suspense fallback={<SectionLoadingSkeleton />}>
                <TimerSection
                  mainSettings={mainSettings}
                  sessionTimer={sessionTimer}
                  onSettingsSaved={checkMainSettings}
                  onOpenAdBlockModal={() => setShowAdBlockModal(true)}
                />
              </Suspense>
            </div>
          )}

          {/* SECTION: تعديل الذوق (Taste Shift) */}
          {dashboardSection === 'taste' && (
            <div id="section-taste" className="space-y-6">
              <Suspense fallback={<SectionLoadingSkeleton />}>
                <TasteShiftCard onSaved={checkMainSettings} />
              </Suspense>
            </div>
          )}

          {/* SECTION: تنظيم وتصنيف القنوات */}
          {dashboardSection === 'channels' && (
            <div id="section-channels" className="space-y-6">
              {/* Live Channels Archive Summary Card */}
              <Suspense fallback={<SectionLoadingSkeleton />}>
                <ChannelsCountCard
                  refreshTrigger={channelsRefreshTrigger}
                  onChannelsLoaded={handleChannelsLoaded}
                />
              </Suspense>

              <Suspense fallback={<SectionLoadingSkeleton />}>
                <ChannelCurationByCategory
                  onChannelChanged={() => setChannelsRefreshTrigger((prev) => prev + 1)}
                />
              </Suspense>
            </div>
          )}

          {/* SECTION: الفلترة والحجب */}
          {dashboardSection === 'filtering' && (
            <div id="section-filtering" className="space-y-6">
              <Suspense fallback={<SectionLoadingSkeleton />}>
                <FilteringTab
                  onFilterChanged={() => {
                    checkMainSettings();
                    setChannelsRefreshTrigger((prev) => prev + 1);
                  }}
                />
              </Suspense>
            </div>
          )}

          {/* SECTION: الفيديوهات المحفوظة */}
          {dashboardSection === 'saved' && (
            <div id="section-saved" className="space-y-6">
              <Suspense fallback={<SectionLoadingSkeleton />}>
                <AddByUrlCard
                  target="saved"
                  onAdded={() => setSavedVideosRefreshTrigger((prev) => prev + 1)}
                />
                <SavedVideosTab
                  key={savedVideosRefreshTrigger}
                  onSelectVideo={handleSelectVideo}
                />
              </Suspense>
            </div>
          )}

          {/* Prominent Bottom Button for First-Run Setup */}
          {!mainSettings?.hasCompletedFirstSetup && (
            <div id="first-run-bottom-action" className="p-6 rounded-3xl bg-yt-brand-soft border-2 border-yt-brand/40 text-center space-y-3 shadow-sm">
              <div className="space-y-1">
                <h4 className="text-base font-bold text-yt-text">
                  هل انتهيت من ضبط الإعدادات والقنوات؟
                </h4>
                <p className="text-xs text-yt-text-muted">
                  يمكنك العودة إلى هنا في أي وقت لاحقاً بإدخال رمز الـ PIN عبر أيقونة القفل.
                </p>
              </div>
              <button
                id="first-run-bottom-start-btn"
                type="button"
                onClick={handleFinishFirstSetup}
                className="px-8 py-3.5 rounded-2xl bg-yt-brand hover:bg-yt-brand-hover text-yt-brand-text text-sm sm:text-base font-bold shadow-md hover:shadow-lg transition cursor-pointer inline-flex items-center gap-2"
              >
                <span>ابدأ استخدام الطفل →</span>
              </button>
            </div>
          )}

          {/* 7. SECTION: أدوات النظام والتشخيص */}
          {dashboardSection === 'tools' && (
            <div id="section-tools" className="space-y-6">
              {/* Helper Bar */}
              <div className="rounded-2xl border border-yt-border bg-yt-surface p-4 text-xs text-yt-text-muted flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-sm">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-yt-text">سجل الإعدادات الثابت:</span>
                  <code className="font-mono bg-yt-surface-muted px-2 py-0.5 rounded text-yt-text">settings.get('main')</code>
                </div>
                <button
                  id="reset-onboarding-test-btn"
                  onClick={handleResetForOnboardingTest}
                  className="text-yt-text-muted hover:text-rose-600 underline font-semibold cursor-pointer"
                >
                  إعادة تجربة شاشة التهيئة (Reset Onboarding)
                </button>
              </div>

              {/* Status Dashboard Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {/* Card 1: Database Test Card */}
              <div
                id="db-test-card"
                className="rounded-2xl border border-yt-border bg-yt-surface p-5 sm:p-6 shadow-sm flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-100 shrink-0">
                        <Database className="w-5 h-5" />
                      </div>
                      <div>
                        <h2 className="text-base font-bold text-yt-text">قاعدة البيانات</h2>
                        <span className="text-xs text-yt-text-muted font-mono">Dexie • v1</span>
                      </div>
                    </div>
                    <button
                      id="retest-db-btn"
                      onClick={runDatabaseTest}
                      disabled={dbResult.loading}
                      className="p-1.5 rounded-lg text-yt-text-muted hover:text-yt-text hover:bg-yt-surface-muted transition disabled:opacity-50 cursor-pointer"
                      title="إعادة الفحص"
                    >
                      <RefreshCw className={`w-4 h-4 ${dbResult.loading ? 'animate-spin' : ''}`} />
                    </button>
                  </div>

                  {/* Status Display */}
                  {dbResult.loading ? (
                    <div className="p-3.5 rounded-xl bg-yt-surface-muted/50 border border-yt-border text-xs text-yt-text-muted animate-pulse flex items-center gap-2">
                      <RefreshCw className="w-4 h-4 animate-spin text-yt-text-muted shrink-0" />
                      جاري اختبار عمليات IndexedDB...
                    </div>
                  ) : dbResult.success ? (
                    <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-950 space-y-1.5">
                      <div className="flex items-center gap-1.5 font-semibold text-emerald-800 text-xs">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                        <span>الكتابة والقراءة والحذف ناجحة</span>
                      </div>
                      <p className="text-[11px] text-emerald-800 leading-relaxed">{dbResult.message}</p>
                      <div className="text-[10px] text-emerald-700 font-mono pt-0.5">
                        آخر فحص: {dbResult.timestamp}
                      </div>
                    </div>
                  ) : (
                    <div className="p-3.5 rounded-xl bg-yt-brand-soft border border-yt-brand/30 text-yt-text space-y-1.5">
                      <div className="flex items-center gap-1.5 font-semibold text-yt-brand text-xs">
                        <AlertTriangle className="w-4 h-4 text-yt-brand shrink-0" />
                        <span>فشل في الفحص</span>
                      </div>
                      <p className="text-[11px] text-yt-brand leading-relaxed">{dbResult.error}</p>
                      <div className="text-[10px] text-yt-text-muted font-mono pt-0.5">
                        آخر فحص: {dbResult.timestamp}
                      </div>
                    </div>
                  )}
                </div>

                {/* Tables Checklist */}
                <div className="mt-4 pt-3 border-t border-yt-border">
                  <div className="flex items-center gap-1.5 text-[11px] font-semibold text-yt-text-muted mb-1.5">
                    <TableProperties className="w-3.5 h-3.5" />
                    <span>6 جداول سكيما معتمدة</span>
                  </div>
                  <div className="flex flex-wrap gap-1 text-[10px] font-mono">
                    <span className="px-1.5 py-0.5 rounded bg-yt-surface-muted text-yt-text">settings</span>
                    <span className="px-1.5 py-0.5 rounded bg-yt-surface-muted text-yt-text">channels</span>
                    <span className="px-1.5 py-0.5 rounded bg-yt-surface-muted text-yt-text">usage</span>
                    <span className="px-1.5 py-0.5 rounded bg-yt-surface-muted text-yt-text">feedCache</span>
                    <span className="px-1.5 py-0.5 rounded bg-yt-surface-muted text-yt-text">interactions</span>
                    <span className="px-1.5 py-0.5 rounded bg-yt-surface-muted text-yt-text">downloads</span>
                  </div>
                </div>
              </div>

              {/* Card 2: Cloudflare Worker Card (with Cache vs Online distinction) */}
              <div
                id="worker-test-card"
                className="rounded-2xl border border-yt-border bg-yt-surface p-5 sm:p-6 shadow-sm flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2.5">
                      <div
                        className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border ${
                          workerResult.isFromCache
                            ? 'bg-yt-brand-soft text-yt-brand border-yt-brand/30'
                            : 'bg-sky-50 text-sky-700 border-sky-200'
                        }`}
                      >
                        <Cloud className="w-5 h-5" />
                      </div>
                      <div>
                        <h2 className="text-base font-bold text-yt-text">الـ Worker</h2>
                        <span className="text-xs text-yt-text-muted font-mono">youngtube-worker</span>
                      </div>
                    </div>
                    <button
                      id="retest-worker-btn"
                      onClick={runWorkerTest}
                      disabled={workerResult.loading}
                      className="p-1.5 rounded-lg text-yt-text-muted hover:text-yt-text hover:bg-yt-surface-muted transition disabled:opacity-50 cursor-pointer"
                      title="إعادة فحص الـ Worker"
                    >
                      <RefreshCw className={`w-4 h-4 ${workerResult.loading ? 'animate-spin' : ''}`} />
                    </button>
                  </div>

                  {/* Worker Status Display with Cache Distinction */}
                  {workerResult.loading ? (
                    <div className="p-3.5 rounded-xl bg-yt-surface-muted/50 border border-yt-border text-xs text-yt-text-muted animate-pulse flex items-center gap-2">
                      <RefreshCw className="w-4 h-4 animate-spin text-yt-text-muted shrink-0" />
                      جاري فحص استجابة الـ Worker...
                    </div>
                  ) : workerResult.success ? (
                    <div
                      className={`p-3.5 rounded-xl border space-y-1.5 ${
                        workerResult.isFromCache
                          ? 'bg-yt-brand-soft border-yt-brand/30 text-yt-text'
                          : 'bg-emerald-50 border-emerald-200 text-emerald-950'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div
                          className={`flex items-center gap-1.5 font-semibold text-xs ${
                            workerResult.isFromCache ? 'text-yt-brand' : 'text-emerald-800'
                          }`}
                        >
                          {workerResult.isFromCache ? (
                            <>
                              <WifiOff className="w-4 h-4 text-yt-brand shrink-0" />
                              <span>من الكاش (بدون اتصال حالي)</span>
                            </>
                          ) : (
                            <>
                              <Wifi className="w-4 h-4 text-emerald-600 shrink-0" />
                              <span>متصل ويرد بنجاح</span>
                            </>
                          )}
                        </div>
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            workerResult.isFromCache
                              ? 'bg-yt-brand/20 text-yt-brand'
                              : 'bg-emerald-200/80 text-emerald-900'
                          }`}
                        >
                          {workerResult.isFromCache ? 'Cache Hit' : 'Network Live'}
                        </span>
                      </div>

                      <pre
                        className={`text-[10px] font-mono p-2 rounded overflow-x-auto border ${
                          workerResult.isFromCache
                            ? 'bg-yt-surface text-yt-text border-yt-border'
                            : 'bg-white/80 text-emerald-950 border-emerald-100'
                        }`}
                      >
                        {JSON.stringify(workerResult.data, null, 2)}
                      </pre>
                      <div
                        className={`text-[10px] font-mono pt-0.5 ${
                          workerResult.isFromCache ? 'text-yt-text-muted' : 'text-emerald-700'
                        }`}
                      >
                        آخر استجابة: {workerResult.timestamp}
                      </div>
                    </div>
                  ) : (
                    <div className="p-3.5 rounded-xl bg-yt-brand-soft border border-yt-brand/30 text-yt-text space-y-1.5">
                      <div className="flex items-center gap-1.5 font-semibold text-yt-brand text-xs">
                        <AlertTriangle className="w-4 h-4 text-yt-brand shrink-0" />
                        <span>تعذر الاتصال بالـ Worker</span>
                      </div>
                      <p className="text-[11px] text-yt-brand leading-relaxed">{workerResult.error}</p>
                      <div className="text-[10px] text-yt-text-muted font-mono pt-0.5">
                        آخر محاولة: {workerResult.timestamp}
                      </div>
                    </div>
                  )}
                </div>

                <div className="mt-4 pt-3 border-t border-yt-border">
                  <div className="text-[11px] text-yt-text-muted truncate">
                    <span className="font-semibold text-yt-text">الرابط: </span>
                    <span className="font-mono text-[10px]">{WORKER_URL}</span>
                  </div>
                </div>
              </div>

              {/* Card 3: Storage Persistence Card */}
              <div
                id="storage-persistence-card"
                className="rounded-2xl border border-yt-border bg-yt-surface p-5 sm:p-6 shadow-sm flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-700 flex items-center justify-center border border-indigo-100 shrink-0">
                        <HardDrive className="w-5 h-5" />
                      </div>
                      <div>
                        <h2 className="text-base font-bold text-yt-text">التخزين الدائم</h2>
                        <span className="text-xs text-yt-text-muted font-mono">storage.persist()</span>
                      </div>
                    </div>
                    <button
                      id="retest-storage-btn"
                      onClick={runStoragePersistenceTest}
                      disabled={storageResult.loading}
                      className="p-1.5 rounded-lg text-yt-text-muted hover:text-yt-text hover:bg-yt-surface-muted transition disabled:opacity-50 cursor-pointer"
                      title="إعادة طلب التخزين الدائم"
                    >
                      <RefreshCw className={`w-4 h-4 ${storageResult.loading ? 'animate-spin' : ''}`} />
                    </button>
                  </div>

                  {/* Storage Status Display */}
                  {storageResult.loading ? (
                    <div className="p-3.5 rounded-xl bg-yt-surface-muted/50 border border-yt-border text-xs text-yt-text-muted animate-pulse flex items-center gap-2">
                      <RefreshCw className="w-4 h-4 animate-spin text-yt-text-muted shrink-0" />
                      جاري فحص صلاحية التخزين الدائم...
                    </div>
                  ) : storageResult.result?.status === 'granted' ? (
                    <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-950 space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5 font-semibold text-emerald-800 text-xs">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                          <span>الحالة: ممنوحة (Granted)</span>
                        </div>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-200/80 text-emerald-900">
                          محمي
                        </span>
                      </div>
                      <p className="text-[11px] text-emerald-800 leading-relaxed">
                        {storageResult.result.message}
                      </p>
                      {storageResult.result.quota && (
                        <div className="text-[10px] text-emerald-800 bg-white/60 p-2 rounded border border-emerald-100">
                          المساحة: {storageResult.result.quota.quotaMb} MB (المستخدم: {storageResult.result.quota.usageMb} MB)
                        </div>
                      )}
                      <div className="text-[10px] text-emerald-700 font-mono pt-0.5">
                        آخر فحص: {storageResult.result.timestamp}
                      </div>
                    </div>
                  ) : storageResult.result?.status === 'denied' ? (
                    <div className="p-3.5 rounded-xl bg-yt-brand-soft border border-yt-brand/30 text-yt-text space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5 font-semibold text-yt-brand text-xs">
                          <AlertTriangle className="w-4 h-4 text-yt-brand shrink-0" />
                          <span>الحالة: مرفوضة (Best-Effort)</span>
                        </div>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-yt-brand/20 text-yt-brand">
                          افتراضي
                        </span>
                      </div>
                      <p className="text-[11px] text-yt-brand leading-relaxed">
                        {storageResult.result.message}
                      </p>
                      {storageResult.result.quota && (
                        <div className="text-[10px] text-yt-text bg-yt-surface p-2 rounded border border-yt-border">
                          المساحة: {storageResult.result.quota.quotaMb} MB (المستخدم: {storageResult.result.quota.usageMb} MB)
                        </div>
                      )}
                      <div className="text-[10px] text-yt-text-muted font-mono pt-0.5">
                        آخر فحص: {storageResult.result.timestamp}
                      </div>
                    </div>
                  ) : (
                    <div className="p-3.5 rounded-xl bg-yt-surface-muted border border-yt-border text-yt-text space-y-1.5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5 font-semibold text-yt-text text-xs">
                          <AlertCircle className="w-4 h-4 text-yt-text-muted shrink-0" />
                          <span>الحالة: غير مدعومة (Unsupported)</span>
                        </div>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-yt-surface text-yt-text-muted">
                          غير متاح
                        </span>
                      </div>
                      <p className="text-[11px] text-yt-text-muted leading-relaxed">
                        {storageResult.result?.message}
                      </p>
                      <div className="text-[10px] text-yt-text-muted font-mono pt-0.5">
                        آخر فحص: {storageResult.result?.timestamp}
                      </div>
                    </div>
                  )}
                </div>

                <div className="mt-4 pt-3 border-t border-yt-border">
                  <div className="text-[11px] text-yt-text-muted">
                    <span className="font-semibold text-yt-text">سياسة البيانات: </span>
                    <span>حماية قاعدة بيانات Dexie والملفات من الحذف التلقائي</span>
                  </div>
                </div>
              </div>

              {/* Card 4: Timer Test Card (Phase 8: Timers) */}
              <div className="md:col-span-2 lg:col-span-3">
                <Suspense fallback={null}>
                  <TimerTestCard
                    secondsUsedToday={sessionTimer.secondsUsedToday}
                    sessionLimitMinutes={sessionTimer.sessionLimitMinutes}
                    isLimitReached={sessionTimer.isLimitReached}
                    isWithinScheduleWindow={sessionTimer.isWithinScheduleWindow}
                    scheduleWindow={sessionTimer.scheduleWindow}
                    onResetToday={sessionTimer.resetTodayUsage}
                    onSimulateLimit={sessionTimer.simulateLimitReached}
                  />
                </Suspense>
              </div>
            </div>
          </div>
        )}
          </DashboardShell>
        </Suspense>
      )}

      <OfflineIndicator />
    </div>
  );
}
