import React, { useRef, useEffect, useState, useCallback } from 'react';
import YouTube, { YouTubeProps } from 'react-youtube';
import type { YouTubePlayer } from 'react-youtube';
import {
  ArrowRight,
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Repeat,
  Settings,
  Cast,
  Heart,
  Download,
  SquarePlay,
  Maximize2,
  EyeOff,
  Ban,
  Bookmark,
  FastForward,
  Rewind,
  X,
  AlertTriangle,
  FolderDown,
  ListPlus,
  Search,
} from 'lucide-react';
import { LandscapeShell } from './LandscapeShell';
import { PlaylistManager } from '../components/PlaylistManager';
import { PlayerSeekBar } from '../components/PlayerSeekBar';
import { PlayerSettingsSheet } from '../components/PlayerSettingsSheet';
import PinLockModal from '../components/PinLockModal';
import { getChannelBySourceId, listRegistryChannels } from '../data/channelRegistry';
import { recordChildReaction, logTasteEvent, applyLoggedTasteEvent } from '../tasteShiftStorage';
import db from '../db';
import { trackFunnelEvent } from '../services/funnelTelemetry';
import { WORKER_URL } from '../config';
import { getFamilyYoutubeApiHeaders } from '../services/youtubeApiKey';
import { startDownload, getDownloadByVideoId } from '../services/downloadManager';
import { castYouTubeVideo } from '../services/castService';
import { Capacitor } from '@capacitor/core';
import { resolvePlaylistQueue } from '../services/playlists/playlistPlayback';
import { canPlayVideoInChildContext } from '../services/playlists/playlistSafety';
import type { PlaylistPlaybackContext } from '../services/playlists/playlistTypes';

export interface QueuedVideo {
  videoId: string;
  title: string;
  channelTitle: string;
  channelId?: string;
}

function formatDuration(seconds: number): string {
  const total = Math.max(0, Math.round(seconds));
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const secs = total % 60;
  return hours > 0
    ? `${hours}:${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`
    : `${minutes}:${String(secs).padStart(2, '0')}`;
}

const DEFAULT_DEMO_QUEUE: QueuedVideo[] = [
  {
    videoId: 's6X_Q54_PBs',
    title: 'Alphablocks - مغامرة الحروف والكلمات الإنجليزية',
    channelTitle: 'Alphablocks',
    channelId: 'UC_qs3c0ehDvZkbiEbOj6Drg',
  },
  {
    videoId: 'u7e33WnUf0A',
    title: 'Numberblocks - أصدقاء الأرقام وتعلم الحساب للأطفال',
    channelTitle: 'Numberblocks',
    channelId: 'UCPlwvN0w4qFSP1FllALB92w',
  },
  {
    videoId: 'x1rB6E1oTss',
    title: 'Art for Kids Hub - تعلم رسم وتلوين الحيوانات بالريشة',
    channelTitle: 'Art for Kids Hub',
    channelId: 'UC5XMF3Inoi8R9nSI8ChOsdQ',
  },
  {
    videoId: 'w_gWvL8fN8g',
    title: 'Arabian Fairy Tales - حكاية الشجرة الحكيمة والطيور الملونة',
    channelTitle: 'Arabian Fairy Tales',
    channelId: 'UCazFScO30FKY3YoNNDfNY5g',
  },
  {
    videoId: '02E1468SdHg',
    title: 'Cosmic Kids Yoga - مغامرة الحركة واليوغا والنشاط الصحي',
    channelTitle: 'Cosmic Kids Yoga',
    channelId: 'UC5uIZ2KOZZeQDQo_Gsi_qbQ',
  },
  {
    videoId: 'UeF09e7hDbg',
    title: '5-Minute Crafts PLAY - أفكار أشغال يدوية وابتكارات بالورق',
    channelTitle: '5-Minute Crafts PLAY',
    channelId: 'UC57XAjJ04TY8gNxOWf-Sy0Q',
  },
  {
    videoId: 'tbCjkPlsaes',
    title: 'AllAttack - مهارات وتحديات رياضية ممتعة للأبطال',
    channelTitle: 'AllAttack',
    channelId: 'UC0Ik25PHaiHCbfGrzu-lBFQ',
  },
];

interface PlayerViewProps {
  videoId: string;
  videoTitle?: string;
  channelTitle?: string;
  channelId?: string;
  localPath?: string;
  playlistContext?: PlaylistPlaybackContext;
  onVideoHidden?: (videoId: string) => void;
  onChannelBlocked?: () => void;
  onOpenChannel?: (channelId: string) => void;
  onOpenSearch?: () => void;
  onRefreshHomeFeed?: () => void;
  onClose: () => void;
  onEnded: () => void;
  forceStop?: boolean;
  isFullscreen?: boolean;
  onEnterFullscreen?: () => void;
  onExitFullscreen?: () => void;
  isMinimized?: boolean;
  onEnterMinimized?: () => void;
  onExitMinimized?: () => void;
  isSheetOpen?: boolean;
  onOpenSheet?: () => void;
  onCloseSheet?: () => void;
  onPlayingChange?: (playing: boolean) => void;
}

export const PlayerView: React.FC<PlayerViewProps> = ({
  videoId,
  videoTitle,
  channelTitle,
  channelId: propChannelId,
  localPath: propLocalPath,
  playlistContext,
  onVideoHidden,
  onChannelBlocked,
  onOpenChannel,
  onOpenSearch,
  onRefreshHomeFeed,
  onClose,
  onEnded,
  forceStop,
  isFullscreen: propIsFullscreen,
  onEnterFullscreen,
  onExitFullscreen,
  isMinimized: propIsMinimized,
  onEnterMinimized,
  onExitMinimized,
  isSheetOpen: propIsSheetOpen,
  onOpenSheet,
  onCloseSheet,
  onPlayingChange,
}) => {
  const playerRef = useRef<YouTubePlayer | null>(null);
  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const videoContainerRef = useRef<HTMLDivElement>(null);
  const [testForceStop, setTestForceStop] = useState(false);

  // Local file playback state
  const [activeLocalPath, setActiveLocalPath] = useState<string | null>(propLocalPath || null);
  const [localPlayError, setLocalPlayError] = useState<string | null>(null);

  // Minimized state (floating mini-player in bottom-right corner)
  const [isMinimizedLocal, setIsMinimizedLocal] = useState(false);
  const isMinimized = (propIsMinimized ?? false) || isMinimizedLocal;
  const isMinimizedRef = useRef(isMinimized);
  isMinimizedRef.current = isMinimized;

  // Primary Player State (declared early to prevent TDZ errors in callbacks & hooks)
  const [isPlaying, setIsPlaying] = useState(true);
  const [loopMode, setLoopMode] = useState<'off' | 'item' | 'playlist'>('off');
  const isLooping = loopMode !== 'off';
  const [playlistShuffle, setPlaylistShuffle] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [showEndedCard, setShowEndedCard] = useState(false);

  // Video Queue & Current Video State
  const [currentVideo, setCurrentVideo] = useState<QueuedVideo>({
    videoId,
    title: videoTitle || 'فيديو أطفال ممتع',
    channelTitle: channelTitle || 'قناة أطفال موثوقة',
    channelId: propChannelId,
  });

  useEffect(() => {
    setCurrentVideo({
      videoId,
      title: videoTitle || 'فيديو أطفال ممتع',
      channelTitle: channelTitle || 'قناة أطفال موثوقة',
      channelId: propChannelId,
    });
    setShowEndedCard(false);
  }, [videoId, videoTitle, channelTitle, propChannelId, playlistContext, playlistShuffle]);

  // Resolve local path from prop or Dexie catalog for current videoId
  useEffect(() => {
    let active = true;
    setLocalPlayError(null);
    async function resolveLocalPath() {
      if (propLocalPath) {
        if (active) setActiveLocalPath(propLocalPath);
        return;
      }
      try {
        const rec = await getDownloadByVideoId(currentVideo.videoId);
        if (active) {
          if (rec && rec.status === 'done' && rec.path) {
            setActiveLocalPath(rec.path);
          } else {
            setActiveLocalPath(null);
          }
        }
      } catch {
        if (active) setActiveLocalPath(null);
      }
    }
    resolveLocalPath();
    return () => {
      active = false;
    };
  }, [currentVideo.videoId, propLocalPath]);

  const convertedLocalSrc = React.useMemo(() => {
    if (!activeLocalPath) return '';
    try {
      return Capacitor.convertFileSrc(activeLocalPath);
    } catch {
      return activeLocalPath;
    }
  }, [activeLocalPath]);

  // Expanding from minimized back to portrait
  const performExpandFromMinimized = useCallback(() => {
    setIsMinimizedLocal(false);
    onExitMinimized?.();
    try {
      playerRef.current?.playVideo?.();
      setIsPlaying(true);
    } catch (err) {
      console.warn('playVideo on expand failed:', err);
    }
  }, [onExitMinimized]);

  const handleExpandFromMinimized = useCallback(() => {
    performExpandFromMinimized();
  }, [performExpandFromMinimized]);

  const handleEnterMinimized = useCallback(() => {
    setIsMinimizedLocal(true);
    if (onEnterMinimized) {
      onEnterMinimized();
    }
  }, [onEnterMinimized]);

  // Taste Shift phase D event logging refs
  const openedVideoIdsRef = useRef(new Set<string>());
  const completedVideoIdsRef = useRef(new Set<string>());
  const skippedVideoIdsRef = useRef(new Set<string>());

  const getCategoryForVideo = useCallback(
    async (vidId: string, chId?: string): Promise<string> => {
      if (chId) {
        const channel = await getChannelBySourceId(chId);
        if (channel?.category && channel.category.length > 0) {
          return channel.category[0];
        }
      }
      try {
        const feedRow = await db.feedCache.get(vidId);
        if (feedRow?.channelId) {
          const channel = await getChannelBySourceId(feedRow.channelId);
          if (channel?.category && channel.category.length > 0) {
            return channel.category[0];
          }
        }
      } catch {}
      return 'general';
    },
    []
  );

  const checkAndLogSkippedEarly = useCallback(
    (vId: string, cur: number, dur: number, chId?: string) => {
      if (dur > 0 && cur > 0 && cur / dur < 0.2 && !skippedVideoIdsRef.current.has(vId)) {
        skippedVideoIdsRef.current.add(vId);
        void (async () => {
          const catId = await getCategoryForVideo(vId, chId || propChannelId);
          await logTasteEvent(catId, 'skipped_early', vId, { watchMs: Math.round(cur * 1000) });
          await applyLoggedTasteEvent(catId, 'skipped_early');
        })();
      }
    },
    [getCategoryForVideo, propChannelId]
  );

  const handleMiniPlayerClose = useCallback(() => {
    checkAndLogSkippedEarly(currentVideo.videoId, currentTime, duration, currentVideo.channelId);
    try {
      playerRef.current?.stopVideo?.();
    } catch (err) {
      console.warn('stopVideo on mini-close failed:', err);
    }
    setIsPlaying(false);
    setIsMinimizedLocal(false);
    onExitMinimized?.();
    onClose();
  }, [checkAndLogSkippedEarly, currentVideo, currentTime, duration, onClose, onExitMinimized]);

  // When isMinimized transitions from true -> false, auto-resume video
  const prevMinimizedRef = useRef(isMinimized);
  useEffect(() => {
    if (prevMinimizedRef.current && !isMinimized) {
      try {
        playerRef.current?.playVideo?.();
        setIsPlaying(true);
      } catch (err) {
        console.warn('playVideo on expand transition failed:', err);
      }
    }
    prevMinimizedRef.current = isMinimized;
  }, [isMinimized]);

  // Fix 1: Two independent facts
  const [isDeviceLandscape, setIsDeviceLandscape] = useState(() => {
    if (typeof window !== 'undefined' && window.matchMedia) {
      return window.matchMedia('(orientation: landscape)').matches;
    }
    return false;
  });
  const [isFullscreenActive, setIsFullscreenActive] = useState(() => {
    if (typeof document !== 'undefined') {
      return Boolean(document.fullscreenElement || (document as any).webkitFullscreenElement);
    }
    return false;
  });

  // Track if user manually exited fullscreen while device is physically landscape
  const [manuallyExitedInLandscape, setManuallyExitedInLandscape] = useState(false);

  // Reconciled effective fullscreen state:
  // - propIsFullscreen if controlled from App
  // - isFullscreenActive comes strictly from document.fullscreenElement / webkitFullscreenElement
  // Physical device landscape alone does NOT auto-switch to LandscapeShell
  const isFullscreen =
    (propIsFullscreen ?? false) ||
    isFullscreenActive;

  const isFullscreenActiveRef = useRef(isFullscreen);
  isFullscreenActiveRef.current = isFullscreen;

  const isDeviceLandscapeRef = useRef(isDeviceLandscape);
  isDeviceLandscapeRef.current = isDeviceLandscape;

  const [showLandscapeControls, setShowLandscapeControls] = useState(true);

  useEffect(() => {
    if (isFullscreen) {
      setShowLandscapeControls(true);
    }
  }, [isFullscreen]);

  const [playlist, setPlaylist] = useState<QueuedVideo[]>(() => {
    const list = [...DEFAULT_DEMO_QUEUE];
    if (!list.some((v) => v.videoId === videoId)) {
      list.unshift({
        videoId,
        title: videoTitle || 'فيديو أطفال ممتع',
        channelTitle: channelTitle || 'قناة أطفال موثوقة',
        channelId: propChannelId,
      });
    }
    return list;
  });

  const [playlistItemIds, setPlaylistItemIds] = useState<string[]>([]);
  const currentPlaylistItemIdRef = useRef<string | null>(playlistContext?.playlistItemId ?? null);

  useEffect(() => {
    currentPlaylistItemIdRef.current = playlistContext?.playlistItemId ?? null;
  }, [playlistContext?.playlistItemId]);

  // Merge with bounded cached feed if present in Dexie (excluding hidden videos)
  useEffect(() => {
    let isCancelled = false;
    async function loadFeedQueue() {
      if (playlistContext?.source === 'playlist' && playlistContext.playlistId) {
        try {
          const resolved = await resolvePlaylistQueue(playlistContext.playlistId, currentPlaylistItemIdRef.current ?? playlistContext.playlistItemId, { shuffle: playlistContext.shuffle ?? playlistShuffle });
          if (isCancelled) return;
          setPlaylist(resolved.items);
          setPlaylistItemIds(resolved.itemIds);
          const target = resolved.items[resolved.currentIndex] ?? resolved.items[0];
          if (target) {
            currentPlaylistItemIdRef.current = resolved.itemIds[resolved.currentIndex] ?? resolved.itemIds[0] ?? null;
            setCurrentVideo(target);
            lastSecondRef.current = 0;
            setCurrentTime(0);
          }
        } catch (err) {
          console.warn('Failed to load playlist queue:', err);
          if (!isCancelled) { setPlaylist([]); setPlaylistItemIds([]); }
        }
        return;
      }
      try {
        const currentItem: QueuedVideo = {
          videoId,
          title: videoTitle || 'فيديو أطفال ممتع',
          channelTitle: channelTitle || 'قناة أطفال موثوقة',
          channelId: propChannelId,
        };

        const channelIdToQuery = propChannelId;
        let sameChannelItems: QueuedVideo[] = [];

        const toQueuedVideo = (f: { videoId: string; title: string; channelId?: string }, fallbackTitle: string) => ({
          videoId: f.videoId,
          title: f.title,
          channelTitle: fallbackTitle,
          channelId: f.channelId,
        });

        const filterSafeQueueItems = async (
          items: Array<{ videoId: string; title: string; channelId?: string }>,
          fallbackTitle: string,
        ): Promise<QueuedVideo[]> => {
          const decisions = await Promise.all(
            items.map(async (item) => ({
              item,
              decision: await canPlayVideoInChildContext(item.videoId),
            }))
          );
          return decisions
            .filter(({ decision }) => decision.allowed)
            .map(({ item }) => toQueuedVideo(item, fallbackTitle));
        };

        // 1. Fetch videos from the same channel if channelId is available, sorted by fetchedAt desc
        if (channelIdToQuery) {
          try {
            const rawSame = await db.feedCache
              .where('channelId')
              .equals(channelIdToQuery)
              .toArray();
            (rawSame || []).sort((a, b) => (b.fetchedAt || 0) - (a.fetchedAt || 0));
            sameChannelItems = await filterSafeQueueItems(
              (rawSame || []).slice(0, 20),
              channelTitle || 'قناة أطفال موثوقة',
            );
          } catch (e) {
            console.warn('Channel query fallback:', e);
          }
        }

        // 2. Fetch up to 30 recent items from feedCache using orderBy('fetchedAt').reverse().limit(30)
        let recentFeedItems: QueuedVideo[] = [];
        try {
          const rawRecent = await db.feedCache.orderBy('fetchedAt').reverse().limit(30).toArray();
            recentFeedItems = await filterSafeQueueItems(
              rawRecent || [],
              'قناة أطفال موثوقة',
            );
        } catch (e) {
          console.warn('Recent feed query fallback:', e);
        }

        if (isCancelled) return;

        const seen = new Set<string>();
        const fallback = sameChannelItems.length > 0
          ? sameChannelItems
          : recentFeedItems.length > 0
            ? recentFeedItems
            : await filterSafeQueueItems(DEFAULT_DEMO_QUEUE, 'قناة أطفال موثوقة');
        const bounded: QueuedVideo[] = [];
        for (const item of [currentItem, ...fallback]) {
          if (!seen.has(item.videoId)) {
            seen.add(item.videoId);
            bounded.push(item);
          }
          if (bounded.length >= 9) break;
        }
        setPlaylist(bounded);
      } catch (err) {
        console.warn('Failed to load bounded feed queue:', err);
      }
    }
    loadFeedQueue();
    return () => {
      isCancelled = true;
    };
  }, [videoId, videoTitle, channelTitle, propChannelId, playlistContext, playlistShuffle]);

  // Current Time & Duration tracking (optimizing re-renders: setState at most once per second or on seek/change)
  const lastSecondRef = useRef(-1);

  useEffect(() => {
    const timer = setInterval(() => {
      if (activeLocalPath && !localPlayError && localVideoRef.current) {
        const cur = localVideoRef.current.currentTime || 0;
        const dur = localVideoRef.current.duration || 0;
        const sec = Math.floor(cur);

        if (sec !== lastSecondRef.current) {
          lastSecondRef.current = sec;
          setCurrentTime(cur);
        }
        if (dur > 0 && Math.abs(dur - duration) > 0.5) {
          setDuration(dur);
        }
        return;
      }

      if (playerRef.current) {
        try {
          const cur = playerRef.current.getCurrentTime?.() || 0;
          const dur = playerRef.current.getDuration?.() || 0;
          const sec = Math.floor(cur);

          if (sec !== lastSecondRef.current) {
            lastSecondRef.current = sec;
            setCurrentTime(cur);
          }
          if (dur > 0 && Math.abs(dur - duration) > 0.5) {
            setDuration(dur);
          }
          if (dur > 0 && cur / dur >= 0.8) {
            const vId = currentVideo.videoId;
            if (!completedVideoIdsRef.current.has(vId)) {
              completedVideoIdsRef.current.add(vId);
              void (async () => {
                const catId = await getCategoryForVideo(vId, currentVideo.channelId || propChannelId);
                await logTasteEvent(catId, 'completed', vId, { watchMs: Math.round(cur * 1000) });
                await applyLoggedTasteEvent(catId, 'completed');
              })();
            }
          }
        } catch {}
      }
    }, 350);
    return () => clearInterval(timer);
  }, [duration, activeLocalPath, localPlayError, currentVideo, getCategoryForVideo, propChannelId]);

  const handleSeek = useCallback((targetSeconds: number) => {
    if (activeLocalPath && !localPlayError && localVideoRef.current) {
      localVideoRef.current.currentTime = targetSeconds;
      lastSecondRef.current = Math.floor(targetSeconds);
      setCurrentTime(targetSeconds);
      return;
    }

    if (!playerRef.current) return;
    try {
      if (typeof playerRef.current.seekTo === 'function') {
        playerRef.current.seekTo(targetSeconds, true);
      }
      lastSecondRef.current = Math.floor(targetSeconds);
      setCurrentTime(targetSeconds);
    } catch (err) {
      console.warn('Seek failed:', err);
    }
  }, [activeLocalPath, localPlayError]);

  // Video switching via loadVideoById (no black flash, same instance)
  const handlePlayQueuedVideo = useCallback((item: QueuedVideo, itemId?: string) => {
    checkAndLogSkippedEarly(currentVideo.videoId, currentTime, duration, currentVideo.channelId);
    if (playlistContext?.source === 'playlist') currentPlaylistItemIdRef.current = itemId ?? currentPlaylistItemIdRef.current;
    setCurrentVideo(item);
    setShowEndedCard(false);
    lastSecondRef.current = 0;
    setCurrentTime(0);
    try {
      playerRef.current?.loadVideoById?.(item.videoId);
      setIsPlaying(true);
    } catch (err) {
      console.warn('loadVideoById failed:', err);
    }
  }, [checkAndLogSkippedEarly, currentVideo, currentTime, duration, playlistContext]);

  const handlePrev = useCallback(() => {
    if (playlist.length === 0) return;
    const curIdx = playlist.findIndex((v) => v.videoId === currentVideo.videoId);
    if (playlistContext?.source === 'playlist') {
      const prevIdx = curIdx > 0 ? curIdx - 1 : loopMode === 'playlist' ? playlist.length - 1 : -1;
      const prevItem = prevIdx >= 0 ? playlist[prevIdx] : undefined;
      if (prevItem) handlePlayQueuedVideo(prevItem, playlistItemIds[prevIdx]);
      return;
    }
    const prevIdx = curIdx > 0 ? curIdx - 1 : playlist.length - 1;
    const prevItem = playlist[prevIdx];
    if (prevItem) handlePlayQueuedVideo(prevItem);
  }, [playlist, currentVideo.videoId, handlePlayQueuedVideo, playlistContext, loopMode, playlistItemIds]);

  const handleNext = useCallback(() => {
    if (playlist.length === 0) return;
    const curIdx = playlist.findIndex((v) => v.videoId === currentVideo.videoId);
    if (playlistContext?.source === 'playlist') {
      const nextIdx = curIdx >= 0 && curIdx + 1 < playlist.length ? curIdx + 1 : loopMode === 'playlist' ? 0 : -1;
      const nextItem = nextIdx >= 0 ? playlist[nextIdx] : undefined;
      if (nextItem) handlePlayQueuedVideo(nextItem, playlistItemIds[nextIdx]);
      else {
        setShowEndedCard(true);
        setIsPlaying(false);
        onPlayingChange?.(false);
        onEnded();
      }
      return;
    }
    const nextIdx = curIdx >= 0 ? (curIdx + 1) % playlist.length : 0;
    const nextItem = playlist[nextIdx];
    if (nextItem) handlePlayQueuedVideo(nextItem);
  }, [playlist, currentVideo.videoId, handlePlayQueuedVideo, playlistContext, loopMode, playlistItemIds, onEnded]);

  // Helper: Resolve channelId robustly
  const resolveChannelId = useCallback(
    async (vidId: string, chTitle?: string, fallbackId?: string): Promise<string> => {
      if (fallbackId) return fallbackId;
      if (currentVideo.channelId) return currentVideo.channelId;
      try {
        const feedRow = await db.feedCache.get(vidId);
        if (feedRow?.channelId) return feedRow.channelId;
        const inter = await db.interactions.get(vidId);
        if (inter?.channelId) return inter.channelId;
        const foundInPlaylist = playlist.find((p) => p.videoId === vidId);
        if (foundInPlaylist?.channelId) return foundInPlaylist.channelId;
        if (chTitle) {
          const ch = await db.channels.where('title').equals(chTitle).first();
          if (ch?.sourceId) return ch.sourceId;
          const regCh = (await listRegistryChannels()).find(
            (c) => c.title === chTitle
          );
          if (regCh?.sourceId) return regCh.sourceId;
        }
      } catch (err) {
        console.warn('resolveChannelId error:', err);
      }
      return chTitle || vidId;
    },
    [currentVideo.channelId, playlist]
  );

  // Love / Favorite state (persisted via Dexie interactions childLoved)
  const [isLoved, setIsLoved] = useState(false);

  useEffect(() => {
    let isMounted = true;
    async function checkLoved() {
      try {
        const interaction = await db.interactions.get(currentVideo.videoId);
        if (isMounted) {
          setIsLoved(Boolean(interaction?.childLoved || interaction?.parentRating === 'liked'));
        }
      } catch (err) {
        console.warn('Failed to check interaction:', err);
      }
    }
    checkLoved();
    return () => {
      isMounted = false;
    };
  }, [currentVideo.videoId]);

  const handleToggleLove = useCallback(async () => {
    const nextLoved = !isLoved;
    setIsLoved(nextLoved);

    try {
      const existing = await db.interactions.get(currentVideo.videoId);
      if (existing) {
        await db.interactions.update(currentVideo.videoId, {
          childLoved: nextLoved,
          ...(existing.parentRating === 'liked' ? { parentRating: undefined } : {}),
          lastWatched: Date.now(),
        });
      } else {
        const targetChannelId = await resolveChannelId(
          currentVideo.videoId,
          currentVideo.channelTitle,
          propChannelId
        );
        await db.interactions.put({
          videoId: currentVideo.videoId,
          channelId: targetChannelId,
          title: currentVideo.title,
          thumbnail: `https://i.ytimg.com/vi/${currentVideo.videoId}/hqdefault.jpg`,
          watchTime: 0,
          videoDuration: 0,
          completed: false,
          lastWatched: Date.now(),
          childLoved: nextLoved,
        });
      }

      if (nextLoved) {
        const realCat = await getCategoryForVideo(currentVideo.videoId, currentVideo.channelId || propChannelId);
        void recordChildReaction({
          categoryId: realCat,
          videoId: currentVideo.videoId,
          channelId: currentVideo.channelId || propChannelId,
          title: currentVideo.title,
          reaction: 'liked',
        });
      }
    } catch (err) {
      console.warn('Failed to record love reaction:', err);
    }
  }, [isLoved, currentVideo, propChannelId, resolveChannelId, getCategoryForVideo]);

  // Save (Parent Bookmark) state (persisted via Dexie interactions.savedByParent)
  const [isSavedByParent, setIsSavedByParent] = useState(false);
  const [isDownloadingCurrent, setIsDownloadingCurrent] = useState(false);
  const [downloadNotice, setDownloadNotice] = useState<string | null>(null);

  const showDownloadNotice = useCallback((msg: string) => {
    setDownloadNotice(msg);
    setTimeout(() => setDownloadNotice(null), 3000);
  }, []);

  useEffect(() => {
    let isMounted = true;
    async function checkSaved() {
      try {
        const interaction = await db.interactions.get(currentVideo.videoId);
        if (isMounted) {
          setIsSavedByParent(Boolean(interaction?.savedByParent));
        }
      } catch (err) {
        console.warn('Failed to check saved interaction:', err);
      }
    }
    checkSaved();
    return () => {
      isMounted = false;
    };
  }, [currentVideo.videoId]);

  const handleStartDownload = useCallback(async () => {
    if (isDownloadingCurrent) return;

    try {
      const existing = await getDownloadByVideoId(currentVideo.videoId);
      if (existing && existing.status === 'done') {
        showDownloadNotice('محمّل مسبقًا');
        return;
      }

      setIsDownloadingCurrent(true);
      showDownloadNotice('بدأ التنزيل...');

      const targetChannelId = await resolveChannelId(
        currentVideo.videoId,
        currentVideo.channelTitle,
        propChannelId
      );

      const res = await startDownload({
        videoId: currentVideo.videoId,
        title: currentVideo.title,
        thumbnailUrl: `https://i.ytimg.com/vi/${currentVideo.videoId}/hqdefault.jpg`,
        channelTitle: currentVideo.channelTitle,
        channelId: targetChannelId,
      });

      if (res.ok) {
        showDownloadNotice('تم اكتمال التنزيل');
      } else {
        showDownloadNotice(res.message || 'تعذر التنزيل');
      }
    } catch (err: any) {
      showDownloadNotice(err?.message || 'خطأ أثناء التنزيل');
    } finally {
      setIsDownloadingCurrent(false);
    }
  }, [isDownloadingCurrent, currentVideo, propChannelId, resolveChannelId, showDownloadNotice]);

  const handleToggleSave = useCallback(async () => {
    const nextSaved = !isSavedByParent;
    setIsSavedByParent(nextSaved);

    try {
      const existing = await db.interactions.get(currentVideo.videoId);
      if (existing) {
        await db.interactions.update(currentVideo.videoId, {
          savedByParent: nextSaved,
          lastWatched: Date.now(),
        });
      } else {
        const targetChannelId = await resolveChannelId(
          currentVideo.videoId,
          currentVideo.channelTitle,
          propChannelId
        );
        await db.interactions.put({
          videoId: currentVideo.videoId,
          channelId: targetChannelId,
          title: currentVideo.title,
          thumbnail: `https://i.ytimg.com/vi/${currentVideo.videoId}/hqdefault.jpg`,
          watchTime: 0,
          videoDuration: 0,
          completed: false,
          lastWatched: Date.now(),
          savedByParent: nextSaved,
        });
      }
    } catch (err) {
      console.warn('Failed to update savedByParent interaction:', err);
    }
  }, [isSavedByParent, currentVideo, propChannelId, resolveChannelId]);

  const effectiveForceStop = forceStop || testForceStop;

  // Settings Bottom Sheet State (delegated to App.tsx history manager when provided)
  const [isSettingsOpenLocal, setIsSettingsOpenLocal] = useState(false);
  const [activeSheet, setActiveSheet] = useState<'settings' | 'description' | null>(null);
  const isSettingsOpen = (propIsSheetOpen !== undefined) ? propIsSheetOpen : isSettingsOpenLocal;

  const openSheet = useCallback((sheet: 'settings' | 'description') => {
    setActiveSheet(sheet);
    if (onOpenSheet) {
      onOpenSheet();
    } else {
      if (typeof window !== 'undefined' && !window.history.state?.sheetOpen) {
        window.history.pushState({ ...window.history.state, ytPlayer: true, sheetOpen: true }, '');
      }
      setIsSettingsOpenLocal(true);
    }
  }, [onOpenSheet]);

  const handleOpenSettings = useCallback(() => openSheet('settings'), [openSheet]);
  const handleOpenDescription = useCallback(() => openSheet('description'), [openSheet]);

  const handleCastVideo = useCallback(async () => {
    const result = await castYouTubeVideo(videoId, videoTitle);
    setDownloadNotice(result.message);
    window.setTimeout(() => setDownloadNotice(null), 4500);
  }, [videoId, videoTitle]);

  const handleCloseSettings = useCallback(() => {
    if (typeof window !== 'undefined' && window.history.state?.sheetOpen) {
      window.history.back();
    } else {
      setIsSettingsOpenLocal(false);
      setActiveSheet(null);
      onCloseSheet?.();
    }
  }, [onCloseSheet]);

  useEffect(() => {
    if (!isSettingsOpen) setActiveSheet(null);
  }, [isSettingsOpen]);

  // Close sheet if video enters fullscreen, is minimized, or receives forceStop
  useEffect(() => {
    if ((isFullscreen || isMinimized || effectiveForceStop) && isSettingsOpen) {
      if (typeof window !== 'undefined' && window.history.state?.sheetOpen) {
        window.history.back();
      } else {
        setIsSettingsOpenLocal(false);
        onCloseSheet?.();
      }
    }
  }, [isFullscreen, isMinimized, effectiveForceStop, isSettingsOpen, onCloseSheet]);

  const handleTogglePlay = useCallback(() => {
    if (activeLocalPath && !localPlayError && localVideoRef.current) {
      if (isPlaying) {
        localVideoRef.current.pause();
        setIsPlaying(false);
      } else {
        localVideoRef.current.play().catch(console.warn);
        setIsPlaying(true);
      }
      return;
    }

    if (!playerRef.current) return;
    try {
      if (isPlaying) {
        playerRef.current.pauseVideo?.();
        setIsPlaying(false);
      } else {
        playerRef.current.playVideo?.();
        setIsPlaying(true);
      }
    } catch (err) {
      console.warn('handleTogglePlay failed:', err);
    }
  }, [isPlaying, activeLocalPath, localPlayError]);

  const handleToggleLoop = useCallback(() => {
    setLoopMode((prev) => prev === 'off' ? 'item' : prev === 'item' ? 'playlist' : 'off');
  }, []);

  const handleToggleShuffle = useCallback(() => {
    if (playlistContext?.source !== 'playlist') return;
    const idx = playlist.findIndex((v) => v.videoId === currentVideo.videoId);
    currentPlaylistItemIdRef.current = playlistItemIds[idx] ?? currentPlaylistItemIdRef.current;
    setPlaylistShuffle((prev) => !prev);
  }, [playlistContext, playlist, currentVideo.videoId, playlistItemIds]);

  const performExitFullscreen = useCallback(async () => {
    setIsFullscreenActive(false);
    setManuallyExitedInLandscape(true);
    onExitFullscreen?.();

    try {
      if (document.fullscreenElement || (document as any).webkitFullscreenElement) {
        if (typeof document.exitFullscreen === 'function') {
          await document.exitFullscreen().catch(() => {});
        } else if ((document as any).webkitExitFullscreen) {
          (document as any).webkitExitFullscreen();
        }
      }
    } catch (err) {
      console.warn('exitFullscreen error:', err);
    }

    try {
      if (screen.orientation && typeof (screen.orientation as any).unlock === 'function') {
        (screen.orientation as any).unlock();
      }
    } catch (err) {
      console.warn('screen.orientation.unlock not supported:', err);
    }
  }, [onExitFullscreen]);

  const handleExitFullscreen = useCallback(() => {
    // Fix 2, Point 4: When exiting via in-app button, call history.back()
    // instead of directly calling exitFullscreen() yourself — let popstate handler
    // be the single place that actually performs the exit
    if (typeof window !== 'undefined' && window.history.state?.fullscreen) {
      window.history.back();
    } else {
      performExitFullscreen();
    }
  }, [performExitFullscreen]);

  const performEnterFullscreen = useCallback(async () => {
    const el = videoContainerRef.current;
    if (el) {
      try {
        if (typeof el.requestFullscreen === 'function' && !document.fullscreenElement) {
          await el.requestFullscreen().catch(() => {});
        } else if ((el as any).webkitRequestFullscreen && !(document as any).webkitFullscreenElement) {
          (el as any).webkitRequestFullscreen();
        }
      } catch (err) {
        console.warn('requestFullscreen error:', err);
      }
    }

    // Orientation lock attempt (landscape) - wrap in try/catch without visible errors
    try {
      if (screen.orientation && typeof (screen.orientation as any).lock === 'function') {
        await (screen.orientation as any).lock('landscape').catch(() => {});
      }
    } catch (err) {
      console.warn('screen.orientation.lock not supported:', err);
    }
  }, []);

  const handleEnterFullscreen = useCallback(() => {
    setManuallyExitedInLandscape(false);
    setIsFullscreenActive(true);
    if (onEnterFullscreen) {
      onEnterFullscreen();
    } else if (typeof window !== 'undefined' && !window.history.state?.fullscreen) {
      window.history.pushState({ ytPlayer: true, fullscreen: true }, '');
    }
    performEnterFullscreen();
  }, [onEnterFullscreen, performEnterFullscreen]);

  // Playlist Manager Modal State
  const [isPlaylistManagerOpen, setIsPlaylistManagerOpen] = useState(false);
  const [pendingPlaylistManagerOpen, setPendingPlaylistManagerOpen] = useState(false);

  const handleOpenPlaylistManager = useCallback(() => {
    if (isFullscreenActiveRef.current || isFullscreen) {
      setPendingPlaylistManagerOpen(true);
      handleExitFullscreen();
    } else {
      setIsPlaylistManagerOpen(true);
    }
  }, [isFullscreen, handleExitFullscreen]);

  const handleClosePlaylistManager = useCallback(() => {
    setIsPlaylistManagerOpen(false);
    setPendingPlaylistManagerOpen(false);
  }, []);

  // When exiting fullscreen, open playlist manager if it was requested from fullscreen
  useEffect(() => {
    if (!isFullscreen && pendingPlaylistManagerOpen) {
      setPendingPlaylistManagerOpen(false);
      setIsPlaylistManagerOpen(true);
    }
  }, [isFullscreen, pendingPlaylistManagerOpen]);

  // Close playlist manager if video is minimized or receives forceStop
  useEffect(() => {
    if (isMinimized || effectiveForceStop) {
      setIsPlaylistManagerOpen(false);
      setPendingPlaylistManagerOpen(false);
    }
  }, [isMinimized, effectiveForceStop]);

  // Sync if propIsFullscreen changes from outside
  useEffect(() => {
    if (propIsFullscreen === false && isFullscreenActiveRef.current) {
      performExitFullscreen();
    }
  }, [propIsFullscreen, performExitFullscreen]);

  // Listen to fullscreen changes, Escape key, and REAL orientation changes (Fix 1)
  useEffect(() => {
    const onFullscreenChange = () => {
      const isNowFs = Boolean(document.fullscreenElement || (document as any).webkitFullscreenElement);
      setIsFullscreenActive(isNowFs);
      if (!isNowFs) {
        setManuallyExitedInLandscape(true);
        try {
          if (screen.orientation && typeof (screen.orientation as any).unlock === 'function') {
            (screen.orientation as any).unlock();
          }
        } catch {
          // ignore
        }
        // Sync history if needed
        if (typeof window !== 'undefined' && window.history.state?.fullscreen) {
          window.history.back();
        }
      }
    };

    document.addEventListener('fullscreenchange', onFullscreenChange);
    document.addEventListener('webkitfullscreenchange', onFullscreenChange);

    // Fix 1, Point 1: Track REAL device orientation via matchMedia('(orientation: landscape)')
    const mql = typeof window !== 'undefined' && window.matchMedia ? window.matchMedia('(orientation: landscape)') : null;
    const handleMediaChange = (e: MediaQueryListEvent | MediaQueryList) => {
      const isLandscapeNow = e.matches;
      setIsDeviceLandscape(isLandscapeNow);
      // Device rotation alone does NOT auto-enter fullscreen or switch to LandscapeShell
    };

    if (mql) {
      if (mql.addEventListener) {
        mql.addEventListener('change', handleMediaChange);
      } else if ((mql as any).addListener) {
        (mql as any).addListener(handleMediaChange);
      }
    }

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isFullscreenActiveRef.current) {
        handleExitFullscreen();
      }
    };
    window.addEventListener('keydown', handleKeyDown);

    const handleScreenOrientationChange = () => {
      if (screen.orientation?.type?.startsWith('portrait') && isFullscreenActiveRef.current) {
        handleExitFullscreen();
      }
    };
    screen.orientation?.addEventListener?.('change', handleScreenOrientationChange);

    return () => {
      document.removeEventListener('fullscreenchange', onFullscreenChange);
      document.removeEventListener('webkitfullscreenchange', onFullscreenChange);
      if (mql) {
        if (mql.removeEventListener) {
          mql.removeEventListener('change', handleMediaChange);
        } else if ((mql as any).removeListener) {
          (mql as any).removeListener(handleMediaChange);
        }
      }
      window.removeEventListener('keydown', handleKeyDown);
      screen.orientation?.removeEventListener?.('change', handleScreenOrientationChange);
    };
  }, [handleEnterFullscreen, handleExitFullscreen]);

  // Force stop video playback immediately when forceStop turns true
  useEffect(() => {
    if (effectiveForceStop) {
      onPlayingChange?.(false);
      if (playerRef.current) {
        try {
          playerRef.current.stopVideo?.();
        } catch (err) {
          console.warn('Failed to stop video on forceStop signal:', err);
        }
      }
    }
  }, [effectiveForceStop, onPlayingChange]);

  // Clean up playback and fullscreen on unmount
  useEffect(() => {
    return () => {
      onPlayingChange?.(false);
      try {
        playerRef.current?.stopVideo?.();
      } catch {
        // ignore
      }
      try {
        if (document.fullscreenElement && typeof document.exitFullscreen === 'function') {
          document.exitFullscreen().catch(() => {});
        }
      } catch {
        // ignore
      }
    };
  }, [onPlayingChange]);

  const handleReady: YouTubeProps['onReady'] = (event) => {
    playerRef.current = event.target;
  };

  const handleStateChange: YouTubeProps['onStateChange'] = (event) => {
    // 1: PLAYING
    if (event.data === 1) {
      setIsPlaying(true);
      onPlayingChange?.(true);

      // Funnel telemetry: first_play (once per install)
      try {
        const firstPlayKey = 'yt_funnel_first_play';
        if (!localStorage.getItem(firstPlayKey)) {
          localStorage.setItem(firstPlayKey, '1');
          trackFunnelEvent('first_play');
        }
      } catch {
        // Fail-open: ignore storage errors
      }

      const vId = currentVideo.videoId;
      if (!openedVideoIdsRef.current.has(vId)) {
        openedVideoIdsRef.current.add(vId);
        void (async () => {
          const catId = await getCategoryForVideo(vId, currentVideo.channelId || propChannelId);
          await logTasteEvent(catId, 'opened', vId);
        })();
      }
    }
    // 2: PAUSED
    else if (event.data === 2) {
      setIsPlaying(false);
      onPlayingChange?.(false);
    }
    // 0: ENDED
    else if (event.data === 0) {
      if (loopMode === 'item') {
        try {
          event.target?.seekTo?.(0, true);
          event.target?.playVideo?.();
          setIsPlaying(true);
          onPlayingChange?.(true);
        } catch {
          // ignore
        }
      } else if (playlistContext?.source === 'playlist') {
        const curIdx = playlist.findIndex((v) => v.videoId === currentVideo.videoId);
        const nextIdx = curIdx >= 0 && curIdx + 1 < playlist.length ? curIdx + 1 : loopMode === 'playlist' ? 0 : -1;
        if (nextIdx >= 0 && playlist[nextIdx]) {
          handlePlayQueuedVideo(playlist[nextIdx], playlistItemIds[nextIdx]);
          setIsPlaying(true);
          onPlayingChange?.(true);
          return;
        }
        setIsPlaying(false);
        onPlayingChange?.(false);
        setShowEndedCard(true);
        onEnded();
      } else {
        setIsPlaying(false);
        onPlayingChange?.(false);
        setShowEndedCard(true);
        const vId = currentVideo.videoId;
        if (!completedVideoIdsRef.current.has(vId)) {
          completedVideoIdsRef.current.add(vId);
          void (async () => {
            const catId = await getCategoryForVideo(vId, currentVideo.channelId || propChannelId);
            await logTasteEvent(catId, 'completed', vId, { watchMs: Math.round(currentTime * 1000) });
            await applyLoggedTasteEvent(catId, 'completed');
          })();
        }
        try {
          event.target?.stopVideo?.();
        } catch {
          // ignore
        }
        onEnded();
      }
    }
  };

  const handleReplay = useCallback(() => {
    setShowEndedCard(false);
    setCurrentTime(0);
    if (activeLocalPath && localVideoRef.current) {
      localVideoRef.current.currentTime = 0;
      localVideoRef.current.play().catch(() => {});
      setIsPlaying(true);
      onPlayingChange?.(true);
      return;
    }
    try {
      playerRef.current?.seekTo?.(0, true);
      playerRef.current?.playVideo?.();
      setIsPlaying(true);
      onPlayingChange?.(true);
    } catch {}
  }, [activeLocalPath, onPlayingChange]);

  const hasPlaylistNext = playlistContext?.source === 'playlist' && (() => {
    const idx = playlist.findIndex((v) => v.videoId === currentVideo.videoId);
    return idx >= 0 && idx + 1 < playlist.length;
  })();

  const handleClose = useCallback(() => {
    checkAndLogSkippedEarly(currentVideo.videoId, currentTime, duration, currentVideo.channelId);
    if (isFullscreen) {
      handleExitFullscreen();
    } else {
      onClose();
    }
  }, [checkAndLogSkippedEarly, currentVideo, currentTime, duration, isFullscreen, handleExitFullscreen, onClose]);

  // Hide Video state & handler
  const [hideConfirmed, setHideConfirmed] = useState(false);
  const hideTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    setHideConfirmed(false);
  }, [currentVideo.videoId]);

  const handleHideVideo = useCallback(async () => {
    if (hideConfirmed) return;
    setHideConfirmed(true);

    try {
      const existing = await db.feedCache.get(currentVideo.videoId);
      if (existing) {
        await db.feedCache.update(currentVideo.videoId, { hidden: true });
      } else {
        const targetChannelId = await resolveChannelId(
          currentVideo.videoId,
          currentVideo.channelTitle,
          propChannelId
        );
        await db.feedCache.put({
          videoId: currentVideo.videoId,
          channelId: targetChannelId,
          title: currentVideo.title,
          fetchedAt: Date.now(),
          hidden: true,
        });
      }

      // Remove from local playlist immediately
      setPlaylist((prev) => prev.filter((v) => v.videoId !== currentVideo.videoId));

      onVideoHidden?.(currentVideo.videoId);
      onRefreshHomeFeed?.();
    } catch (err) {
      console.error('Failed to hide video:', err);
    }

    hideTimerRef.current = setTimeout(() => {
      handleClose();
    }, 1500);
  }, [hideConfirmed, currentVideo, propChannelId, resolveChannelId, onVideoHidden, onRefreshHomeFeed, handleClose]);

  useEffect(() => {
    return () => {
      if (hideTimerRef.current) {
        clearTimeout(hideTimerRef.current);
      }
    };
  }, []);

  // Block Channel PIN Gate & handler
  const [showBlockChannelPinModal, setShowBlockChannelPinModal] = useState(false);

  const handleBlockChannelClick = useCallback(() => {
    setShowBlockChannelPinModal(true);
  }, []);

  const handleBlockChannelCancel = useCallback(() => {
    setShowBlockChannelPinModal(false);
  }, []);

  const handleBlockChannelUnlocked = useCallback(async () => {
    setShowBlockChannelPinModal(false);

    try {
      let targetChannelId = await resolveChannelId(
        currentVideo.videoId,
        currentVideo.channelTitle,
        propChannelId
      );

      if (targetChannelId.startsWith('@')) {
        try {
          const familyHeaders = await getFamilyYoutubeApiHeaders();
          const res = await fetch(`${WORKER_URL}/api/resolve-channel?handle=${encodeURIComponent(targetChannelId.replace(/^@+/, ''))}`, { headers: familyHeaders });
          if (res.ok) {
            const data = await res.json();
            if (data.sourceId && !data.sourceId.startsWith('@')) {
              targetChannelId = data.sourceId;
            }
          }
        } catch {}
      }

      // 1. db.channels: find row or create with enabled: false
      const existing = await db.channels.where('sourceId').equals(targetChannelId).first();
      if (existing && existing.id) {
        await db.channels.update(existing.id, { enabled: false });
      } else if (!targetChannelId.startsWith('@')) {
        const regMatch = await getChannelBySourceId(targetChannelId);
        await db.channels.add({
          sourceType: 'channel',
          sourceId: targetChannelId,
          title: regMatch?.title || currentVideo.channelTitle || 'قناة محجوبة',
          thumbnail: regMatch?.thumbnail,
          category: regMatch?.category || [],
          isPreloaded: true,
          enabled: false,
        });
      }

      // 2. Mark all cached videos for this channel as hidden
      const cachedVideos = await db.feedCache.where('channelId').equals(targetChannelId).toArray();
      if (cachedVideos.length > 0) {
        await Promise.all(
          cachedVideos.map((v) => db.feedCache.update(v.videoId, { hidden: true }))
        );
      }

      // Remove any video from this channel from local playlist
      setPlaylist((prev) => prev.filter((v) => v.channelId !== targetChannelId));

      onChannelBlocked?.();
      onRefreshHomeFeed?.();
      handleClose();
    } catch (err) {
      console.error('Failed to block channel:', err);
      handleClose();
    }
  }, [currentVideo, propChannelId, resolveChannelId, onChannelBlocked, onRefreshHomeFeed, handleClose]);

  // ================= PORTRAIT GESTURE LAYER (Unified Pointer-Event State Machine) =================
  const [showPortraitControls, setShowPortraitControls] = useState(true);
  const [seekFeedback, setSeekFeedback] = useState<{
    direction: 'forward' | 'backward';
    key: number;
  } | null>(null);
  const seekFeedbackTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const activePointerRef = useRef<{
    pointerId: number;
    startX: number;
    startY: number;
    startTime: number;
    lastX: number;
    lastY: number;
    hasMovedPastThreshold: boolean;
  } | null>(null);

  const lastTapRef = useRef<{
    x: number;
    y: number;
    time: number;
  } | null>(null);

  const singleTapTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const handleSeekBy = useCallback((deltaSeconds: number) => {
    if (!playerRef.current) return;
    try {
      const currentTime =
        typeof playerRef.current.getCurrentTime === 'function'
          ? playerRef.current.getCurrentTime()
          : 0;
      const newTime = Math.max(0, currentTime + deltaSeconds);
      if (typeof playerRef.current.seekTo === 'function') {
        playerRef.current.seekTo(newTime, true);
      }

      if (seekFeedbackTimerRef.current) {
        clearTimeout(seekFeedbackTimerRef.current);
      }
      setSeekFeedback({
        direction: deltaSeconds > 0 ? 'forward' : 'backward',
        key: Date.now(),
      });
      seekFeedbackTimerRef.current = setTimeout(() => {
        setSeekFeedback(null);
      }, 700);
    } catch (err) {
      console.warn('Seek failed:', err);
    }
  }, []);

  const handlePointerDown = useCallback((e: React.PointerEvent<HTMLDivElement>) => {
    // Only handle primary pointer (first finger touch or left mouse click)
    if (!e.isPrimary) return;
    if (e.target !== e.currentTarget) return;

    try {
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    } catch {
      // Ignore if pointer capture fails
    }

    activePointerRef.current = {
      pointerId: e.pointerId,
      startX: e.clientX,
      startY: e.clientY,
      startTime: Date.now(),
      lastX: e.clientX,
      lastY: e.clientY,
      hasMovedPastThreshold: false,
    };
  }, []);

  const handlePointerMove = useCallback((e: React.PointerEvent<HTMLDivElement>) => {
    const session = activePointerRef.current;
    if (!session || session.pointerId !== e.pointerId) return;

    session.lastX = e.clientX;
    session.lastY = e.clientY;

    const dx = e.clientX - session.startX;
    const dy = e.clientY - session.startY;
    const dist = Math.hypot(dx, dy);

    // Movement threshold ~10px before committing to swipe-tracking
    if (!session.hasMovedPastThreshold && dist >= 10) {
      session.hasMovedPastThreshold = true;
      // Committed to swipe: cancel any pending single-tap and clear double-tap candidate
      if (singleTapTimerRef.current) {
        clearTimeout(singleTapTimerRef.current);
        singleTapTimerRef.current = null;
      }
      lastTapRef.current = null;
    }

    if (session.hasMovedPastThreshold && e.cancelable) {
      e.preventDefault();
    }
  }, []);

  const handlePointerUp = useCallback(
    (e: React.PointerEvent<HTMLDivElement>) => {
      const session = activePointerRef.current;
      if (!session || session.pointerId !== e.pointerId) return;

      try {
        (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
      } catch {
        // Ignore
      }

      activePointerRef.current = null;

      const endX = e.clientX;
      const endY = e.clientY;
      const deltaX = endX - session.startX;
      const deltaY = endY - session.startY;
      const absX = Math.abs(deltaX);
      const absY = Math.abs(deltaY);

      // CLASSIFY GESTURE ONLY AFTER COMPLETION (Unified Pointer State Machine)

      // 1. Swipe classification: movement >= 10px, net vertical displacement magnitude >= 80px, vertical dominant
      if (session.hasMovedPastThreshold && absY >= 80 && absY > absX) {
        if (e.cancelable) {
          e.preventDefault();
        }
        if (singleTapTimerRef.current) {
          clearTimeout(singleTapTimerRef.current);
          singleTapTimerRef.current = null;
        }
        lastTapRef.current = null;

        if (deltaY < -80) {
          // Gesture 1: Swipe UP on video area -> Fullscreen (when in Portrait)
          if (!isFullscreenActiveRef.current) {
            handleEnterFullscreen();
          }
          return;
        } else if (deltaY > 80) {
          // Gesture 2: Swipe DOWN
          // Branch on current mode (Landscape vs Portrait)
          if (isFullscreenActiveRef.current) {
            // Landscape/Fullscreen mode: swipe-down returns to Portrait player while continuing playback uninterrupted
            handleExitFullscreen();
          } else {
            // Portrait mode: swipe-down pauses playback and enters floating mini-player
            try {
              playerRef.current?.pauseVideo?.();
            } catch (err) {
              console.warn('pauseVideo on swipe-down failed:', err);
            }
            setIsPlaying(false);
            handleEnterMinimized();
          }
          return;
        }
      }

      // 2. Aborted / partial drag: moved > 10px but didn't reach 80px threshold -> discard (not a tap)
      if (session.hasMovedPastThreshold) {
        if (singleTapTimerRef.current) {
          clearTimeout(singleTapTimerRef.current);
          singleTapTimerRef.current = null;
        }
        lastTapRef.current = null;
        return;
      }

      // 3. Clean Tap Sequence: movement was < 10px
      const now = Date.now();
      const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
      const clickX = endX - rect.left;
      const widthRatio = rect.width > 0 ? clickX / rect.width : 0.5;

      const lastTap = lastTapRef.current;
      const isDoubleTap =
        lastTap !== null &&
        now - lastTap.time <= 300 &&
        Math.hypot(endX - lastTap.x, endY - lastTap.y) < 40;

      if (isDoubleTap) {
        // Double-tap detected: cancel pending single tap
        if (singleTapTimerRef.current) {
          clearTimeout(singleTapTimerRef.current);
          singleTapTimerRef.current = null;
        }
        lastTapRef.current = null;

        // Double-tap classification by horizontal region
        if (widthRatio > 2 / 3) {
          // Gesture 3: Double-tap right third -> seek forward 10s
          handleSeekBy(10);
        } else if (widthRatio < 1 / 3) {
          // Gesture 4: Double-tap left third -> seek backward 10s
          handleSeekBy(-10);
        } else {
          // Middle third double-tap -> toggle controls
          if (isFullscreenActiveRef.current) {
            setShowLandscapeControls((prev) => !prev);
          } else {
            setShowPortraitControls((prev) => !prev);
          }
        }
      } else {
        // Potential single tap: record position and schedule single-tap action after 300ms window
        lastTapRef.current = { x: endX, y: endY, time: now };

        if (singleTapTimerRef.current) {
          clearTimeout(singleTapTimerRef.current);
        }

        singleTapTimerRef.current = setTimeout(() => {
          // Gesture 5: Single tap on video background -> toggle controls visibility
          if (isFullscreenActiveRef.current) {
            setShowLandscapeControls((prev) => !prev);
          } else {
            setShowPortraitControls((prev) => !prev);
          }
          lastTapRef.current = null;
          singleTapTimerRef.current = null;
        }, 300);
      }
    },
    [handleEnterFullscreen, handleExitFullscreen, handleEnterMinimized, handleSeekBy]
  );

  const handlePointerCancel = useCallback((e: React.PointerEvent<HTMLDivElement>) => {
    if (activePointerRef.current?.pointerId === e.pointerId) {
      try {
        (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
      } catch {}
      activePointerRef.current = null;
    }
  }, []);

  // Clean up gesture timers on unmount
  useEffect(() => {
    return () => {
      if (singleTapTimerRef.current) {
        clearTimeout(singleTapTimerRef.current);
      }
      if (seekFeedbackTimerRef.current) {
        clearTimeout(seekFeedbackTimerRef.current);
      }
    };
  }, []);

  return (
    <div
      id="youngtube-player-view"
      data-surface="player"
      dir="rtl"
      className={
        isMinimized
          ? 'fixed inset-0 z-[80] pointer-events-none bg-transparent select-none'
          : 'fixed inset-0 z-50 bg-yt-bg text-white w-screen overflow-y-auto overscroll-contain select-none'
      }
    >
      {/* ================= TOP HALF / VIDEO AREA (Portrait: 50% height) ================= */}
      <div
        className={
          isFullscreen
            ? 'fixed inset-0 z-50 w-full h-full bg-black overflow-hidden'
            : isMinimized
            ? 'fixed bottom-[calc(56px+env(safe-area-inset-bottom)+8px)] right-3 sm:right-5 z-[60] pointer-events-auto w-[176px] h-[99px] sm:w-[216px] sm:h-[122px] rounded-2xl shadow-2xl shadow-black/90 ring-1 ring-white/20 bg-black flex items-center justify-center transition-all duration-[220ms]'
            : 'w-full max-w-3xl mx-auto flex flex-col bg-yt-surface border-b border-yt-border'
        }
      >
        {/* Top Quarter (25% of top half): Meta & Parent Actions (Portrait only) */}
        {!isFullscreen && !isMinimized && (
          <div className="order-2 px-4 py-3 bg-yt-surface flex items-center justify-between border-t border-yt-border gap-3 shrink-0">
            {/* Back/Close button (top-left / start in RTL) */}
            <button
              type="button"
              id="player-close-btn"
              onClick={handleClose}
              className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/15 flex items-center justify-center text-white transition shrink-0 cursor-pointer active:scale-95"
              aria-label="إغلاق المشغل"
            >
              <ArrowRight className="w-5 h-5" />
            </button>

            <button
              type="button"
              id="player-search-btn"
              onClick={onOpenSearch}
              disabled={!onOpenSearch}
              className={`shrink-0 flex items-center gap-1.5 rounded-full px-3 h-10 bg-white/10 hover:bg-white/15 text-white transition active:scale-95 ${
                showPortraitControls ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
              } ${onOpenSearch ? 'cursor-pointer' : 'cursor-default'}`}
              aria-label="البحث"
              title="البحث"
            >
              <Search className="w-4 h-4" />
              <span className="text-xs font-bold">البحث</span>
            </button>

            {/* Title & Channel Info */}
            <div className="flex-1 min-w-0 px-1 flex items-center gap-2.5">
              <button
                type="button"
                onClick={() => currentVideo.channelId && onOpenChannel?.(currentVideo.channelId)}
                className={`w-10 h-10 rounded-full bg-yt-surface-muted border border-yt-border shrink-0 flex items-center justify-center text-xs font-black text-yt-text-muted overflow-hidden ${currentVideo.channelId && onOpenChannel ? 'cursor-pointer' : 'cursor-default'}`}
                aria-label={`فتح قناة ${currentVideo.channelTitle}`}
              >
                <span>{currentVideo.channelTitle?.trim().charAt(0) || 'ق'}</span>
              </button>
              <div className="min-w-0">
                <h2 className="font-bold text-sm sm:text-base text-yt-text line-clamp-2 leading-snug">
                  {currentVideo.title}
                </h2>
                {currentVideo.channelId && onOpenChannel ? (
                  <button
                    type="button"
                    onClick={() => onOpenChannel(currentVideo.channelId!)}
                    className="text-[11px] text-yt-text-muted hover:text-yt-brand truncate text-right cursor-pointer"
                    aria-label={`فتح قناة ${currentVideo.channelTitle}`}
                  >
                    {currentVideo.channelTitle}
                  </button>
                ) : (
                  <p className="text-[11px] text-yt-text-muted truncate">{currentVideo.channelTitle}</p>
                )}
              </div>
            </div>

            {/* Parent Action Pill Container */}
            <div className="flex items-center gap-1 shrink-0 bg-white/5 border border-white/10 rounded-full px-2.5 py-1">
              <span className="text-yt-brand text-xs shrink-0">🔒</span>
              <button
                type="button"
                id="player-parent-hide-btn"
                onClick={handleHideVideo}
                disabled={hideConfirmed}
                className="hover:text-yt-brand active:scale-95 transition-colors px-1 text-[11px] font-bold text-white/80 cursor-pointer"
                title="إخفاء الفيديو من القائمة"
              >
                {hideConfirmed ? 'تم الإخفاء ✅' : 'إخفاء'}
              </button>
              <span className="text-white/20 text-xs">·</span>
              <button
                type="button"
                id="player-parent-disable-btn"
                onClick={handleBlockChannelClick}
                className="hover:text-rose-300 active:scale-95 transition-colors px-1 text-[11px] font-bold text-white/80 cursor-pointer"
                title="تعطيل القناة (يتطلب رمز الدخول)"
              >
                تعطيل القناة
              </button>
              <span className="text-white/20 text-xs">·</span>
              <button
                type="button"
                id="player-parent-save-btn"
                onClick={handleToggleSave}
                className="hover:text-emerald-300 active:scale-95 transition-colors px-1 text-[11px] font-bold text-white/80 cursor-pointer"
                title={isSavedByParent ? 'إلغاء الحفظ' : 'حفظ في المفضلة للأهل'}
              >
                {isSavedByParent ? 'محفوظ' : 'حفظ'}
              </button>
            </div>
          </div>
        )}

        {/* Video Area Stage (75% of top half): Full width, no padding, no border-radius */}
        <div
          ref={videoContainerRef}
          id="player-video-container"
          className={
            isFullscreen
              ? 'w-full h-full relative bg-black flex items-center justify-center overflow-hidden'
              : isMinimized
              ? 'w-full h-full relative bg-black rounded-2xl overflow-hidden flex items-center justify-center'
              : 'order-1 aspect-video relative bg-black w-full p-0 rounded-none flex items-center justify-center overflow-hidden'
          }
        >
          {activeLocalPath && !localPlayError ? (
            <div className="relative w-full h-full bg-black flex items-center justify-center">
              <video
                ref={localVideoRef}
                src={convertedLocalSrc}
                autoPlay
                playsInline
                className="w-full h-full object-contain bg-black"
                onPlay={() => {
                  setIsPlaying(true);
                  onPlayingChange?.(true);
                }}
                onPause={() => {
                  setIsPlaying(false);
                  onPlayingChange?.(false);
                }}
                onTimeUpdate={(e) => {
                  const cur = e.currentTarget.currentTime;
                  setCurrentTime(cur);
                }}
                onLoadedMetadata={(e) => {
                  setDuration(e.currentTarget.duration);
                }}
                onEnded={() => {
                  if (loopMode === 'item') {
                    if (localVideoRef.current) {
                      localVideoRef.current.currentTime = 0;
                      localVideoRef.current.play().catch(console.warn);
                    }
                    return;
                  }
                  if (playlistContext?.source === 'playlist') {
                    const idx = playlist.findIndex((v) => v.videoId === currentVideo.videoId);
                    const nextIdx = idx >= 0 && idx + 1 < playlist.length ? idx + 1 : loopMode === 'playlist' ? 0 : -1;
                    if (nextIdx >= 0 && playlist[nextIdx]) {
                      handlePlayQueuedVideo(playlist[nextIdx], playlistItemIds[nextIdx]);
                      return;
                    }
                  }
                  setIsPlaying(false);
                  onPlayingChange?.(false);
                  setShowEndedCard(true);
                  onEnded();
                }}
                onError={() => {
                  console.error('Local video failed to play:', activeLocalPath);
                  setLocalPlayError('تعذر تشغيل الملف المحلي');
                }}
              />
              {/* Badge: Offline Local Play */}
              <div className="absolute top-3 right-3 z-20 px-2.5 py-1 rounded-full bg-emerald-600/90 backdrop-blur-md text-white text-[10px] font-bold flex items-center gap-1.5 shadow-lg border border-white/20 select-none">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>تشغيل محلي (بدون إنترنت)</span>
              </div>
            </div>
          ) : localPlayError ? (
            <div className="w-full h-full bg-yt-surface-muted flex flex-col items-center justify-center text-center p-6 space-y-3 z-10">
              <div className="w-12 h-12 rounded-2xl bg-rose-500/10 text-rose-400 flex items-center justify-center border border-rose-500/20">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <p className="text-xs font-bold text-yt-text">{localPlayError}</p>
              {!navigator.onLine && (
                <p className="text-[11px] text-yt-text-muted">
                  أنت حالياً غير متصل بالإنترنت ولم يتم العثور على ملف محلي صالح.
                </p>
              )}
            </div>
          ) : (
            <YouTube
              videoId={currentVideo.videoId}
              className="w-full h-full"
              iframeClassName="w-full h-full object-cover border-0 block"
              opts={{
                host: 'https://www.youtube-nocookie.com',
                width: '100%',
                height: '100%',
                playerVars: {
                  rel: 0,
                  modestbranding: 1,
                  autoplay: 1,
                  controls: 0,
                  disablekb: 1,
                  playsinline: 1,
                  fs: 0,
                  iv_load_policy: 3,
                  cc_load_policy: 0,
                },
              }}
              onReady={handleReady}
              onStateChange={handleStateChange}
              onEnd={() => {}}
            />
          )}

          {/* Soft top & bottom cinematic ambient gradient overlays on video */}
          <div className="absolute inset-x-0 top-0 h-12 bg-gradient-to-b from-black/50 to-transparent pointer-events-none z-10" />
          <div className="absolute inset-x-0 bottom-0 h-10 bg-gradient-to-t from-black/70 to-transparent pointer-events-none z-10" />

          {/* Landscape Shell Overlay when in Fullscreen */}
          {isFullscreen ? (
            <LandscapeShell
              isPlaying={isPlaying}
              isLooping={isLooping}
              isLoved={isLoved}
              currentTime={currentTime}
              duration={duration}
              videoTitle={currentVideo.title}
              channelTitle={currentVideo.channelTitle}
              onTogglePlay={handleTogglePlay}
              onToggleLoop={handleToggleLoop}
              onToggleLove={handleToggleLove}
              onAddToPlaylist={handleOpenPlaylistManager}
              onPrev={handlePrev}
              onNext={handleNext}
              onSeek={handleSeek}
              onExitFullscreen={handleExitFullscreen}
              onOpenSearch={onOpenSearch}
              onPointerDown={handlePointerDown}
              onPointerMove={handlePointerMove}
              onPointerUp={handlePointerUp}
              onPointerCancel={handlePointerCancel}
              showOverlay={showLandscapeControls}
              setShowOverlay={setShowLandscapeControls}
            />
          ) : isMinimized ? (
            /* Minimized Mini-Player Body Tap Target */
            <div
              id="mini-player-body-tap"
              onClick={handleExpandFromMinimized}
              className="absolute inset-0 z-20 cursor-pointer flex items-center justify-center bg-black/20 hover:bg-black/35 transition group rounded-2xl"
              aria-label="تكبير واستئناف المشاهدة"
              title="انقر لاستئناف المشاهدة وتكبير المشغل"
            >
              <div className="w-9 h-9 rounded-full bg-black/60 border border-white/20 text-white flex items-center justify-center opacity-85 group-hover:opacity-100 group-hover:scale-105 transition shadow-md pointer-events-none">
                <Play className="w-4 h-4 fill-white text-white translate-x-0.5" />
              </div>
            </div>
          ) : (
            /* Portrait Gesture Layer & Single Fullscreen Button on stage */
            <>
              {/* Unified Pointer-Event Gesture Layer for Portrait Mode */}
              <div
                id="player-portrait-gesture-layer"
                onPointerDown={handlePointerDown}
                onPointerMove={handlePointerMove}
                onPointerUp={handlePointerUp}
                onPointerCancel={handlePointerCancel}
                className="absolute inset-0 z-10 bg-transparent cursor-pointer touch-none select-none"
                aria-label="منطقة إيماءات مشغل الفيديو"
              />

              {/* Portrait Fullscreen Button: Backdrop-blur circular button */}
              <button
                type="button"
                id="player-fullscreen-btn"
                className={`absolute top-3 left-3 z-20 w-10 h-10 rounded-full bg-black/60 backdrop-blur-md border border-white/20 text-white flex items-center justify-center hover:bg-black/80 active:scale-90 transition-all shadow-md cursor-pointer ${
                  showPortraitControls ? 'opacity-100' : 'opacity-0 pointer-events-none'
                }`}
                aria-label="تكبير الشاشة بالكامل"
                onClick={handleEnterFullscreen}
                title="عرض بملء الشاشة"
              >
                <Maximize2 className="w-5 h-5 text-white" />
              </button>
            </>
          )}

          {/* Seek Feedback Indicators (Active in both Portrait and Landscape) */}
          {seekFeedback && (
            <div
              key={seekFeedback.key}
              className={`absolute top-0 bottom-0 z-40 flex items-center justify-center pointer-events-none transition-all duration-300 ${
                seekFeedback.direction === 'forward'
                  ? 'right-0 w-1/3 bg-white/10 rounded-l-3xl backdrop-blur-[1px]'
                  : 'left-0 w-1/3 bg-white/10 rounded-r-3xl backdrop-blur-[1px]'
              }`}
            >
              <div className="flex flex-col items-center justify-center gap-1.5 text-white bg-black/60 px-4 py-2.5 rounded-2xl border border-white/10 shadow-lg animate-in fade-in zoom-in-95 duration-150">
                {seekFeedback.direction === 'forward' ? (
                  <FastForward className="w-7 h-7 fill-white text-white" />
                ) : (
                  <Rewind className="w-7 h-7 fill-white text-white" />
                )}
                <span className="text-xs font-bold font-mono tracking-wide">
                  {seekFeedback.direction === 'forward' ? '+10s' : '-10s'}
                </span>
              </div>
            </div>
          )}

          {/* Mini-Player Close "X" Button placed inside top-right of mini rectangle */}
          {isMinimized && (
            <button
              type="button"
              id="mini-player-close-btn"
              onClick={(e) => {
                e.stopPropagation();
                handleMiniPlayerClose();
              }}
              className="absolute top-2 right-2 z-30 w-8 h-8 sm:w-8.5 sm:h-8.5 rounded-full bg-black/85 hover:bg-rose-600 text-white border border-white/40 hover:border-white shadow-md shadow-black/80 backdrop-blur-md flex items-center justify-center cursor-pointer transition-all duration-150 active:scale-90"
              aria-label="إغلاق المشغل المصغر"
              title="إغلاق الفيديو"
            >
              <X className="w-4 h-4 text-white stroke-[2.5] drop-shadow-xs" />
            </button>
          )}

          {showEndedCard && !effectiveForceStop && (
            <div className="absolute inset-0 z-40 bg-black/75 backdrop-blur-sm flex flex-col items-center justify-center p-5 text-center">
              <div className="w-full max-w-sm rounded-3xl border border-white/15 bg-black/60 p-5 shadow-2xl">
                <h3 className="text-base font-black text-white">انتهى الفيديو</h3>
                <p className="text-xs text-white/65 mt-1 line-clamp-2">{currentVideo.title}</p>
                <div className="mt-5 grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <button type="button" onClick={handleReplay} className="min-h-11 rounded-2xl bg-white text-black text-xs font-black cursor-pointer active:scale-95 transition">إعادة التشغيل</button>
                  {hasPlaylistNext && <button type="button" onClick={handleNext} className="min-h-11 rounded-2xl bg-yt-brand text-yt-brand-text text-xs font-black cursor-pointer active:scale-95 transition">التالي في القائمة</button>}
                  <button type="button" onClick={onClose} className="min-h-11 rounded-2xl bg-white/10 text-white text-xs font-bold border border-white/10 cursor-pointer active:scale-95 transition">رجوع</button>
                </div>
              </div>
            </div>
          )}

          {/* ForceStop Visual Banner */}
          {effectiveForceStop && (
            <div className="absolute inset-0 z-30 bg-black/80 flex flex-col items-center justify-center p-4 text-center select-none backdrop-blur-sm">
              <div className="w-12 h-12 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center mb-2 border border-rose-500/40">
                <Ban className="w-6 h-6" />
              </div>
              <p className="text-sm font-bold text-rose-200 mb-1">
                تم إيقاف الفيديو فورياً عبر إشارة الأمان (forceStop)
              </p>
              <p className="text-xs text-yt-text-muted mb-3 max-w-xs">
                تم استلام إشارة الإيقاف الإجباري وتم استدعاء stopVideo() بنجاح.
              </p>
              {testForceStop && !forceStop && (
                <button
                  type="button"
                  onClick={() => {
                    setTestForceStop(false);
                    try {
                      playerRef.current?.playVideo?.();
                      setIsPlaying(true);
                    } catch {
                      // ignore
                    }
                  }}
                  className="px-3 py-1.5 rounded-lg bg-yt-surface-muted hover:bg-yt-surface text-yt-text text-xs font-semibold border border-yt-border transition cursor-pointer"
                >
                  إلغاء فحص forceStop واستئناف الفيديو ▶
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* ================= BOTTOM HALF (Portrait only: 50% height, bg-yt-bg) ================= */}
      {!isFullscreen && !isMinimized && (
        <div className="w-full max-w-3xl mx-auto flex flex-col p-4 sm:p-5 bg-yt-bg gap-4">
          {/* 1) Seek bar dir="ltr" + remaining / total time */}
          <div className="w-full">
            <PlayerSeekBar
              id="portrait-player-seek-bar"
              currentTime={currentTime}
              duration={duration}
              onSeek={handleSeek}
            />
          </div>

          {/* 2) Primary group centered (not spread full width): Prev small · Play/Pause 64px circle · Next small */}
          <div className="flex flex-col items-center justify-center gap-3 py-1">
            <div
              dir="ltr"
              className="flex items-center justify-center gap-6 sm:gap-8"
            >
              {/* Previous Button (Secondary small rounded icon) */}
              <button
                type="button"
                id="player-control-prev"
                className="w-12 h-12 rounded-full bg-white/10 hover:bg-white/15 text-white flex items-center justify-center active:scale-90 transition-all border border-white/5 cursor-pointer shadow-sm"
                aria-label="السابق"
                onClick={handlePrev}
              >
                <SkipBack className="w-6 h-6" />
              </button>

              {/* Play/Pause Button: 64px Dominant Control */}
              <button
                type="button"
                id="player-control-play-pause"
                className="w-16 h-16 rounded-full bg-yt-brand hover:bg-yt-brand-hover text-yt-brand-text flex items-center justify-center shadow-[0_8px_24px_rgba(255,159,28,0.45)] border-b-[3px] border-yt-brand-hover active:scale-95 active:translate-y-0.5 transition-transform shrink-0 cursor-pointer"
                aria-label={isPlaying ? 'إيقاف مؤقت' : 'تشغيل'}
                onClick={handleTogglePlay}
              >
                {isPlaying ? (
                  <Pause className="w-8 h-8 fill-current text-current" />
                ) : (
                  <Play className="w-8 h-8 fill-current text-current ml-0.5" />
                )}
              </button>

              {/* Next Button (Secondary small rounded icon) */}
              <button
                type="button"
                id="player-control-next"
                className="w-12 h-12 rounded-full bg-white/10 hover:bg-white/15 text-white flex items-center justify-center active:scale-90 transition-all border border-white/5 cursor-pointer shadow-sm"
                aria-label="التالي"
                onClick={handleNext}
              >
                <SkipForward className="w-6 h-6" />
              </button>
            </div>

            {/* 3) Secondary group: loop · add-to-playlist · download · cast · settings · love */}
            <div className="relative grid grid-cols-6 gap-1 px-1 border-t border-white/5 pt-2 w-full max-w-lg mx-auto items-start justify-items-center">
              {/* Floating Download Toast / Notice */}
              {downloadNotice && (
                <div className="absolute -top-7 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-yt-brand text-yt-brand-text text-[11px] font-bold shadow-md animate-fade-in pointer-events-none whitespace-nowrap z-20">
                  {downloadNotice}
                </div>
              )}

              {/* Loop Toggle */}
              <button
                type="button"
                id="player-control-loop"
                onClick={handleToggleLoop}
                className="flex flex-col items-center gap-1 text-white/70 hover:text-white active:scale-95 transition-all cursor-pointer"
              >
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    isLooping
                      ? 'bg-yt-brand-soft text-yt-brand border border-yt-brand/40'
                      : 'bg-white/5 hover:bg-white/10 text-white/80'
                  }`}
                >
                  <Repeat className="w-5 h-5" />
                </div>
                <span className="text-[11px] font-semibold text-yt-text-muted text-center">تكرار</span>
              </button>

              {/* Add to Playlist Control */}
              <button
                type="button"
                id="player-control-add-to-playlist"
                onClick={handleOpenPlaylistManager}
                className="flex flex-col items-center gap-1 text-white/70 hover:text-white active:scale-95 transition-all cursor-pointer"
                aria-label="إضافة إلى قائمة تشغيل"
                title="إضافة هذا الفيديو إلى قائمة تشغيل"
              >
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    isPlaylistManagerOpen
                      ? 'bg-yt-brand-soft text-yt-brand border border-yt-brand/40'
                      : 'bg-white/5 hover:bg-white/10 text-white/80'
                  }`}
                >
                  <ListPlus className="w-5 h-5" />
                </div>
                <span className="text-[10px] sm:text-[11px] font-semibold text-yt-text-muted text-center leading-tight line-clamp-2">
                  إضافة إلى قائمة تشغيل
                </span>
              </button>

              {/* Download Control */}
              <button
                type="button"
                id="player-control-download"
                onClick={handleStartDownload}
                disabled={isDownloadingCurrent}
                className="flex flex-col items-center gap-1 text-white/70 hover:text-white active:scale-95 transition-all cursor-pointer disabled:opacity-60"
                title="تنزيل الفيديو (360p)"
              >
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    isDownloadingCurrent
                      ? 'bg-yt-brand-soft text-yt-brand border border-yt-brand/40 animate-pulse'
                      : 'bg-white/5 hover:bg-white/10 text-white/80'
                  }`}
                >
                  <Download className={`w-5 h-5 ${isDownloadingCurrent ? 'animate-bounce' : ''}`} />
                </div>
                <span className="text-[11px] font-semibold text-yt-text-muted text-center">
                  {isDownloadingCurrent ? 'جاري التحميل' : 'تنزيل'}
                </span>
              </button>

              {/* Cast / external screen */}
              <button
                type="button"
                id="player-control-cast"
                onClick={handleCastVideo}
                className="flex flex-col items-center gap-1 text-white/70 hover:text-white active:scale-95 transition-all cursor-pointer"
                title="عرض الفيديو على شاشة خارجية أو TV مدعوم"
                aria-label="عرض الفيديو على شاشة خارجية أو TV مدعوم"
              >
                <div className="w-10 h-10 rounded-full flex items-center justify-center bg-white/5 hover:bg-white/10 text-white/80">
                  <Cast className="w-5 h-5" />
                </div>
                <span className="text-[11px] font-semibold text-yt-text-muted text-center">بث</span>
              </button>

              {/* Settings */}
              <button
                type="button"
                id="player-control-settings"
                onClick={handleOpenSettings}
                className="flex flex-col items-center gap-1 text-white/70 hover:text-white active:scale-95 transition-all cursor-pointer"
              >
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    isSettingsOpen
                      ? 'bg-yt-brand-soft text-yt-brand border border-yt-brand/40'
                      : 'bg-white/5 hover:bg-white/10 text-white/80'
                  }`}
                >
                  <Settings className="w-5 h-5" />
                </div>
                <span className="text-[11px] font-semibold text-yt-text-muted text-center">الإعدادات</span>
              </button>

              {/* Love / Favorite */}
              <button
                type="button"
                id="player-control-love"
                onClick={handleToggleLove}
                className="flex flex-col items-center gap-1 text-white/70 hover:text-white active:scale-95 transition-all cursor-pointer"
              >
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    isLoved
                      ? 'bg-rose-500/25 text-rose-400 border border-rose-500/40'
                      : 'bg-white/5 hover:bg-white/10 text-white/80'
                  }`}
                >
                  <Heart
                    className={`w-5 h-5 ${
                      isLoved ? 'fill-rose-500 text-rose-500' : 'text-white/80'
                    }`}
                  />
                </div>
                <span className="text-[11px] font-semibold text-yt-text-muted text-center">المفضلة</span>
              </button>
            </div>
          </div>

          <button
            type="button"
            onClick={handleOpenDescription}
            className="w-full rounded-2xl border border-yt-border bg-yt-surface px-4 py-3 text-right hover:bg-yt-surface-muted active:scale-[0.995] transition cursor-pointer"
            aria-label="عرض تفاصيل الفيديو"
          >
            <div className="flex items-center justify-between gap-3">
              <div className="min-w-0">
                <div className="text-xs font-black text-yt-text">تفاصيل الفيديو</div>
                <div className="text-[11px] text-yt-text-muted mt-1 line-clamp-1">{currentVideo.title}</div>
              </div>
              <span className="shrink-0 text-[11px] font-bold text-yt-brand">عرض</span>
            </div>
          </button>

          {/* 4) Label "التالي في قائمة الأمان" + existing UpNextStrip */}
          <div className="space-y-2 pt-1">
            <div className="flex items-center justify-between px-1">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-yt-brand"></span>
                <span className="text-xs font-bold text-yt-text">التالي في قائمة الأمان</span>
              </div>
              <span className="text-[10px] text-white/40">
                {Math.max(0, playlist.length - 1)} مقاطع معتمدة
              </span>
            </div>
            <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-none overscroll-x-contain touch-pan-x">
              {playlist
                .filter((item) => item.videoId !== currentVideo.videoId)
                .map((item) => (
                  <button
                    key={item.videoId}
                    type="button"
                    onClick={() => handlePlayQueuedVideo(item)}
                    className="shrink-0 w-36 sm:w-44 bg-yt-surface hover:bg-yt-surface-muted rounded-xl border border-yt-border p-2 flex flex-col gap-1.5 text-right cursor-pointer transition active:scale-95 group focus:outline-none focus:ring-1 focus:ring-yt-border"
                  >
                    <div className="relative aspect-video w-full rounded-lg overflow-hidden bg-yt-bg">
                      <img
                        src={`https://i.ytimg.com/vi/${item.videoId}/mqdefault.jpg`}
                        alt={item.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                        loading="lazy"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <span className="text-[11px] font-semibold text-yt-text line-clamp-1 group-hover:text-yt-text">
                      {item.title}
                    </span>
                    <span className="text-[10px] text-yt-text-muted truncate">
                      {item.channelTitle}
                    </span>
                  </button>
                ))}
            </div>
          </div>
        </div>
      )}

      {/* Portrait Playback Sheets */}
      {!isFullscreen && !isMinimized && activeSheet === 'settings' && (
        <PlayerSettingsSheet
          isOpen={isSettingsOpen}
          onClose={handleCloseSettings}
          player={playerRef.current}
        />
      )}
      {!isFullscreen && !isMinimized && activeSheet === 'description' && isSettingsOpen && (
        <div
          id="player-description-sheet"
          className="fixed inset-x-0 bottom-0 z-[82] h-[min(72vh,560px)] bg-yt-bg/70 backdrop-blur-[2px] flex flex-col justify-end animate-in fade-in"
          role="dialog"
          aria-modal="true"
          aria-label="تفاصيل الفيديو"
          onClick={(event) => { if (event.target === event.currentTarget) handleCloseSettings(); }}
        >
          <div dir="rtl" className="w-full h-full bg-yt-surface border-t border-yt-border rounded-t-3xl shadow-2xl overflow-hidden flex flex-col animate-in slide-in-from-bottom-full">
            <div className="pt-2.5 pb-3 px-5 border-b border-yt-border shrink-0">
              <div className="w-10 h-1 bg-yt-border rounded-full mx-auto mb-3" />
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <h2 className="text-base font-black text-yt-text line-clamp-2">{currentVideo.title}</h2>
                  <p className="text-xs text-yt-text-muted mt-1">{currentVideo.channelTitle}</p>
                </div>
                <button type="button" onClick={handleCloseSettings} className="w-10 h-10 rounded-full hover:bg-yt-surface-muted text-yt-text-muted flex items-center justify-center cursor-pointer" aria-label="إغلاق التفاصيل">×</button>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-2xl bg-yt-surface-muted p-3"><div className="text-[10px] text-yt-text-muted">القناة</div><div className="text-sm font-bold mt-1 truncate">{currentVideo.channelTitle}</div></div>
                <div className="rounded-2xl bg-yt-surface-muted p-3"><div className="text-[10px] text-yt-text-muted">المدة</div><div className="text-sm font-bold mt-1">{duration > 0 ? formatDuration(duration) : '—'}</div></div>
              </div>
              <div className="rounded-2xl border border-yt-border bg-yt-bg/40 p-4">
                <div className="text-xs font-black text-yt-text mb-2">الوصف</div>
                <p className="text-xs leading-6 text-yt-text-muted">لا تحتوي بيانات الفيديو المحلية الحالية على نص وصف مستقل لهذا الفيديو. تم إبقاء شاشة التفاصيل متاحة لتوحيد تجربة المشاهدة، من دون اختلاق وصف غير موجود.</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Playlist Manager Modal Overlay */}
      {isPlaylistManagerOpen && !isMinimized && (
        <div
          id="player-playlist-manager-modal"
          className="fixed inset-0 z-[85] flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm p-3 sm:p-4"
          dir="rtl"
          onClick={(e) => {
            e.stopPropagation();
            handleClosePlaylistManager();
          }}
          onPointerDown={(e) => e.stopPropagation()}
          onPointerMove={(e) => e.stopPropagation()}
          onPointerUp={(e) => e.stopPropagation()}
        >
          <div
            className="w-full max-w-md bg-yt-surface rounded-2xl shadow-2xl border border-yt-border overflow-hidden animate-fade-in"
            onClick={(e) => e.stopPropagation()}
            onPointerDown={(e) => e.stopPropagation()}
          >
            <PlaylistManager
              mode="add"
              video={{
                videoId: currentVideo.videoId,
                title: currentVideo.title,
              }}
              onClose={handleClosePlaylistManager}
              onChanged={() => {
                // Refresh list if needed
              }}
            />
          </div>
        </div>
      )}

      {/* PIN Lock Modal for Disabling / Blocking Channel */}
      <PinLockModal
        isOpen={showBlockChannelPinModal}
        onClose={handleBlockChannelCancel}
        onUnlockSuccess={handleBlockChannelUnlocked}
      />
    </div>
  );
};
