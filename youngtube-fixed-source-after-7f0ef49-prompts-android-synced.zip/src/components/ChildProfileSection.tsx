import React, { useState, useEffect, useRef } from 'react';
import db from '../db';
import { useAllCategories } from '../hooks/useAllCategories';
import { User, Heart, ShieldX, Check, Sparkles, Moon, Sun } from 'lucide-react';
import { getInitialTheme, setTheme, type ThemeMode } from '../services/theme';

interface ChildProfileSectionProps {
  onSaved?: () => void;
}

export const ChildProfileSection: React.FC<ChildProfileSectionProps> = ({ onSaved }) => {
  const { curationCategories } = useAllCategories();
  const [childName, setChildName] = useState<string>('');
  const [childAge, setChildAge] = useState<number | ''>('');
  const [positiveInterests, setPositiveInterests] = useState<string[]>([]);
  const [negativeInterests, setNegativeInterests] = useState<string[]>([]);
  const [isLoaded, setIsLoaded] = useState<boolean>(false);
  const [saveStatus, setSaveStatus] = useState<'saved' | 'saving' | 'idle'>('idle');
  const [themeMode, setThemeMode] = useState<ThemeMode>(() => {
    if (typeof document !== 'undefined' && document.documentElement.dataset.theme) {
      return (document.documentElement.dataset.theme as ThemeMode) || 'light';
    }
    return getInitialTheme();
  });

  const handleSelectTheme = (mode: ThemeMode) => {
    setTheme(mode);
    setThemeMode(mode);
  };

  // Track if this is the first load to prevent saving defaults on mount
  const isFirstLoad = useRef(true);
  const debounceTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Load initial settings
  useEffect(() => {
    let isMounted = true;
    async function loadSettings() {
      try {
        const settings = await db.settings.get('main');
        if (settings && isMounted) {
          setChildName(settings.childName || '');
          setChildAge(settings.childAge !== undefined && settings.childAge !== null ? settings.childAge : '');
          setPositiveInterests(settings.positiveInterests || []);
          setNegativeInterests(settings.negativeInterests || []);
        }
      } catch (err) {
        console.error('Failed to load child profile settings:', err);
      } finally {
        if (isMounted) {
          setIsLoaded(true);
          // Wait a tick before enabling auto-save to ignore initial state setters
          setTimeout(() => {
            isFirstLoad.current = false;
          }, 100);
        }
      }
    }
    loadSettings();
    return () => {
      isMounted = false;
      if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current);
    };
  }, []);

  // Debounced auto-save on change
  useEffect(() => {
    if (isFirstLoad.current || !isLoaded) return;

    setSaveStatus('saving');
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }

    debounceTimerRef.current = setTimeout(async () => {
      try {
        const ageNum = typeof childAge === 'number' ? childAge : undefined;
        await db.settings.update('main', {
          childName: childName.trim(),
          childAge: ageNum,
          positiveInterests,
          negativeInterests,
        });
        setSaveStatus('saved');
        onSaved?.();
        setTimeout(() => setSaveStatus('idle'), 2000);
      } catch (err) {
        console.error('Failed to auto-save child profile:', err);
        setSaveStatus('idle');
      }
    }, 500);

    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
    };
  }, [childName, childAge, positiveInterests, negativeInterests, isLoaded, onSaved]);

  const togglePositive = (catId: string) => {
    setPositiveInterests((prev) => {
      if (prev.includes(catId)) {
        return prev.filter((id) => id !== catId);
      } else {
        // A category can be picked in only one group at a time
        setNegativeInterests((neg) => neg.filter((id) => id !== catId));
        return [...prev, catId];
      }
    });
  };

  const toggleNegative = (catId: string) => {
    setNegativeInterests((prev) => {
      if (prev.includes(catId)) {
        return prev.filter((id) => id !== catId);
      } else {
        // A category can be picked in only one group at a time
        setPositiveInterests((pos) => pos.filter((id) => id !== catId));
        return [...prev, catId];
      }
    });
  };

  return (
    <div id="child-profile-section" className="space-y-5 max-w-4xl mx-auto">
      {/* Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-yt-border">
        <div>
          <h3 className="text-base sm:text-lg font-extrabold text-yt-text flex items-center gap-2">
            <span className="w-8 h-8 rounded-xl bg-yt-brand text-yt-brand-text flex items-center justify-center shrink-0 shadow-sm">
              <User className="w-4 h-4" />
            </span>
            <span>ملف الطفل والاهتمامات</span>
          </h3>
          <p className="text-xs sm:text-sm text-yt-text-muted mt-1">
            خصص اسم الطفل وعمره واهتماماته المفضلة أو المستبعدة لتوجيه المحتوى والأنشطة المناسبة له.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          {saveStatus === 'saving' && (
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-yt-brand-soft text-yt-brand border border-yt-brand/30">
              <span className="w-1.5 h-1.5 rounded-full bg-yt-brand animate-pulse" />
              جاري الحفظ...
            </span>
          )}
          {saveStatus === 'saved' && (
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
              <Check className="w-3.5 h-3.5 text-emerald-600" />
              تم الحفظ تلقائياً
            </span>
          )}
          {saveStatus === 'idle' && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold text-yt-text-muted bg-yt-surface border border-yt-border">
              حفظ فوري في الجهاز
            </span>
          )}
        </div>
      </div>

      {/* Card 1: Name and Age Inputs */}
      <div className="rounded-2xl border border-yt-border bg-yt-surface p-4 sm:p-5 shadow-sm space-y-4">
        <h4 className="text-xs sm:text-sm font-bold text-yt-text">
          البيانات الأساسية للطفل
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label htmlFor="child-name-input" className="text-xs font-bold text-yt-text block">
              اسم الطفل
            </label>
            <input
              id="child-name-input"
              type="text"
              value={childName}
              onChange={(e) => setChildName(e.target.value)}
              placeholder="مثال: يوسف، سارة..."
              className="w-full min-h-[44px] px-3.5 py-2.5 text-xs sm:text-sm rounded-xl border border-yt-border bg-yt-surface-muted hover:bg-yt-surface focus:bg-yt-surface text-yt-text focus:outline-hidden focus:ring-2 focus:ring-yt-brand/30 focus:border-yt-brand transition"
            />
            <span className="text-[11px] text-yt-text-muted block">
              يظهر في عبارات الترحيب والتشجيع
            </span>
          </div>

          <div className="space-y-1.5">
            <label htmlFor="child-age-input" className="text-xs font-bold text-yt-text block">
              عمر الطفل (بالسنوات)
            </label>
            <input
              id="child-age-input"
              type="number"
              min="2"
              max="16"
              value={childAge}
              onChange={(e) => {
                const val = e.target.value;
                setChildAge(val === '' ? '' : Math.max(1, Math.min(18, Number(val))));
              }}
              placeholder="مثال: 6"
              className="w-full min-h-[44px] px-3.5 py-2.5 text-xs sm:text-sm rounded-xl border border-yt-border bg-yt-surface-muted hover:bg-yt-surface focus:bg-yt-surface text-yt-text focus:outline-hidden focus:ring-2 focus:ring-yt-brand/30 focus:border-yt-brand font-mono transition"
            />
            <span className="text-[11px] text-yt-text-muted block">
              يساعد في موائمة طبيعة المحتوى والأنشطة للمرحلة العمرية
            </span>
          </div>
        </div>
      </div>

      {/* Card 2: Positive Interests Multi-select */}
      <div className="rounded-2xl border border-yt-border bg-yt-surface p-4 sm:p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="space-y-1">
            <label className="text-xs sm:text-sm font-bold text-yt-text flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                <Heart className="w-3.5 h-3.5 text-emerald-600 fill-emerald-600/30" />
              </span>
              <span>اهتمامات مفضلة وموصى بها</span>
            </label>
            <p className="text-xs text-yt-text-muted">
              المجالات التي ترغب في تشجيع طفلك عليها لمضاعفة ظهورها واقتراحها في الخلاصة.
            </p>
          </div>
          <span className="self-start sm:self-auto text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-xl">
            {positiveInterests.length} محددة
          </span>
        </div>

        <div className="flex flex-wrap gap-2 pt-1">
          {curationCategories.map((cat) => {
            const isSelected = positiveInterests.includes(cat.id);
            return (
              <button
                key={`pos-${cat.id}`}
                id={`chip-pos-${cat.id}`}
                type="button"
                onClick={() => togglePositive(cat.id)}
                className={`min-h-[44px] flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition active:scale-[0.98] cursor-pointer select-none ${
                  isSelected
                    ? 'bg-emerald-600 text-white border border-emerald-600 shadow-sm'
                    : 'bg-yt-surface-muted text-yt-text border border-yt-border hover:bg-emerald-50/60 hover:border-emerald-300'
                }`}
              >
                <span className="text-base">{cat.emoji}</span>
                <span>{cat.label}</span>
                {isSelected && <Check className="w-3.5 h-3.5 ml-0.5" />}
              </button>
            );
          })}
        </div>
      </div>

      {/* Card 3: Negative Interests Multi-select */}
      <div className="rounded-2xl border border-yt-border bg-yt-surface p-4 sm:p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="space-y-1">
            <label className="text-xs sm:text-sm font-bold text-yt-text flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center shrink-0">
                <ShieldX className="w-3.5 h-3.5 text-rose-600" />
              </span>
              <span>اهتمامات مستبعدة أو غير مرغوبة</span>
            </label>
            <p className="text-xs text-yt-text-muted">
              المجالات التي ترغب في تجنبها أو عدم ظهور قنواتها لطفلك (اختيار قسم هنا يزيله من المفضلة تلقائياً).
            </p>
          </div>
          <span className="self-start sm:self-auto text-xs font-bold text-rose-700 bg-rose-50 border border-rose-200 px-2.5 py-1 rounded-xl">
            {negativeInterests.length} محددة
          </span>
        </div>

        <div className="flex flex-wrap gap-2 pt-1">
          {curationCategories.map((cat) => {
            const isSelected = negativeInterests.includes(cat.id);
            return (
              <button
                key={`neg-${cat.id}`}
                id={`chip-neg-${cat.id}`}
                type="button"
                onClick={() => toggleNegative(cat.id)}
                className={`min-h-[44px] flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition active:scale-[0.98] cursor-pointer select-none ${
                  isSelected
                    ? 'bg-rose-600 text-white border border-rose-600 shadow-sm'
                    : 'bg-yt-surface-muted text-yt-text border border-yt-border hover:bg-rose-50/60 hover:border-rose-300'
                }`}
              >
                <span className="text-base">{cat.emoji}</span>
                <span>{cat.label}</span>
                {isSelected && <Check className="w-3.5 h-3.5 ml-0.5" />}
              </button>
            );
          })}
        </div>
      </div>

      {/* Card 4: Appearance & Theme (الوضع الليلي / الفاتح) */}
      <div className="rounded-2xl border border-yt-border bg-yt-surface p-4 sm:p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="space-y-1">
            <h4 className="text-xs sm:text-sm font-bold text-yt-text flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg bg-yt-brand-soft text-yt-brand flex items-center justify-center shrink-0">
                {themeMode === 'dark' ? <Moon className="w-3.5 h-3.5" /> : <Sun className="w-3.5 h-3.5" />}
              </span>
              <span>مظهر التطبيق (الوضع الليلي)</span>
            </h4>
            <p className="text-xs text-yt-text-muted">
              اختر المظهر المفضل لك ولطفلك، يتم الحفظ في الجهاز تلقائياً.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
          <button
            type="button"
            id="theme-select-light"
            onClick={() => handleSelectTheme('light')}
            className={`min-h-[48px] flex items-center justify-between px-4 py-3 rounded-xl border text-xs sm:text-sm font-bold transition cursor-pointer select-none ${
              themeMode === 'light'
                ? 'bg-yt-brand-soft border-yt-brand text-yt-brand'
                : 'bg-yt-surface-muted border-yt-border text-yt-text hover:bg-yt-surface'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <Sun className={`w-4 h-4 ${themeMode === 'light' ? 'text-yt-brand' : 'text-yt-text-muted'}`} />
              <span>الوضع الفاتح (نهاري)</span>
            </div>
            {themeMode === 'light' && <Check className="w-4 h-4 text-yt-brand shrink-0" />}
          </button>

          <button
            type="button"
            id="theme-select-dark"
            onClick={() => handleSelectTheme('dark')}
            className={`min-h-[48px] flex items-center justify-between px-4 py-3 rounded-xl border text-xs sm:text-sm font-bold transition cursor-pointer select-none ${
              themeMode === 'dark'
                ? 'bg-yt-brand-soft border-yt-brand text-yt-brand'
                : 'bg-yt-surface-muted border-yt-border text-yt-text hover:bg-yt-surface'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <Moon className={`w-4 h-4 ${themeMode === 'dark' ? 'text-yt-brand' : 'text-yt-text-muted'}`} />
              <span>الوضع الليلي (داكن)</span>
            </div>
            {themeMode === 'dark' && <Check className="w-4 h-4 text-yt-brand shrink-0" />}
          </button>
        </div>
      </div>
    </div>
  );
};
